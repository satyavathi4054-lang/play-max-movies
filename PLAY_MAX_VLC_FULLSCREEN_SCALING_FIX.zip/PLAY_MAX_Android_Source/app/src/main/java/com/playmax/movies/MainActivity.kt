package com.playmax.movies

import android.annotation.SuppressLint
import android.graphics.Color
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.os.Handler
import android.os.Looper
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.Locale
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var adContainer: FrameLayout
    private var bannerView: AdView? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var previousRequestedOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private var appRoot: LinearLayout? = null
    private lateinit var rootFrame: FrameLayout
    private lateinit var playerOverlay: FrameLayout
    private var vlc: LibVLC? = null
    private var vlcPlayer: MediaPlayer? = null
    private var vlcVideo: VLCVideoLayout? = null
    private var playerFullscreen = false
    private var savedPlayerRect = intArrayOf(0, 0, 0, 0)
    private var savedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    private val playerHandler = Handler(Looper.getMainLooper())
    private var playerSeek: SeekBar? = null
    private var playerTime: TextView? = null
    private var seeking = false
    // Preserve VLC playback position/state while the app is backgrounded or the screen is locked.
    private var lifecyclePlaybackTime: Long = 0L
    private var lifecycleWasPlaying: Boolean = false
    private var vlcViewsDetachedForPause: Boolean = false
    private val playerProgress = object : Runnable {
        override fun run() {
            val mp = vlcPlayer
            val bar = playerSeek
            if (mp != null && bar != null && !seeking) {
                val len = mp.length.coerceAtLeast(1L)
                bar.max = len.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                bar.progress = mp.time.coerceIn(0L, len).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                playerTime?.text = "${timeText(mp.time)} / ${timeText(mp.length)}"
            }
            if (vlcPlayer != null) playerHandler.postDelayed(this, 500)
        }
    }

    // PLAY MAX Banner Ad Unit ID supplied by the user. No interstitial ads are used.
    private val bannerAdUnitId = "ca-app-pub-1802093280158632/2546818349"

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private inner class PlayMaxShareBridge {
        @JavascriptInterface
        fun share(text: String, title: String) {
            runOnUiThread {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, title)
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(sendIntent, "Share with"))
            }
        }
    }

    private inner class PlayMaxPlayerBridge {
        @JavascriptInterface
        fun play(url: String, title: String, x: Float, y: Float, width: Float, height: Float) {
            if (url.isBlank()) return
            runOnUiThread { showInlineVlc(url, title, x, y, width, height) }
        }
        @JavascriptInterface fun updatePosition(x: Float, y: Float, width: Float, height: Float) {
            runOnUiThread { updateInlineVlcPosition(x, y, width, height) }
        }
        @JavascriptInterface fun stop() { runOnUiThread { stopInlineVlc() } }

        @JavascriptInterface
        fun openDownload(url: String) {
            if (url.isBlank()) return
            val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return
            if (uri.scheme != "http" && uri.scheme != "https") return
            runOnUiThread {
                // Remove the native VLC surface before navigating to the download page.
                stopInlineVlc()
                if (::webView.isInitialized) webView.loadUrl(uri.toString())
            }
        }
    }


    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        rootFrame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }
        appRoot = root

        // Apply system insets once only, preventing duplicate top/bottom offsets in WebView.
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val safeBars = insets.getInsets(
                WindowInsetsCompat.Type.statusBars() or
                    WindowInsetsCompat.Type.navigationBars() or
                    WindowInsetsCompat.Type.displayCutout()
            )
            view.setPadding(safeBars.left, safeBars.top, safeBars.right, safeBars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadsImagesAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    if (::playerOverlay.isInitialized && playerOverlay.visibility == View.VISIBLE) {
            stopInlineVlc()
        } else if (customView != null) {
                        callback.onCustomViewHidden()
                        return
                    }

                    customView = view
                    customViewCallback = callback
                    previousRequestedOrientation = requestedOrientation
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

                    (window.decorView as? FrameLayout)?.addView(
                        view,
                        FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            Gravity.CENTER
                        )
                    )
                    webView.visibility = View.GONE
                    adContainer.visibility = View.GONE
                    window.addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
                }

                override fun onHideCustomView() {
                    val view = customView ?: return
                    (window.decorView as? FrameLayout)?.removeView(view)
                    customView = null
                    webView.visibility = View.VISIBLE
                    adContainer.visibility = View.VISIBLE
                    window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
                    requestedOrientation = previousRequestedOrientation
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                }
            }
            addJavascriptInterface(PlayMaxShareBridge(), "PlayMaxBridge")
            addJavascriptInterface(PlayMaxPlayerBridge(), "PlayMaxPlayer")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest
                ): Boolean = handleExternalTelegramLink(request.url.toString())

                @Suppress("DEPRECATION")
                override fun shouldOverrideUrlLoading(view: WebView?, url: String): Boolean =
                    handleExternalTelegramLink(url)
            }
            setBackgroundColor(Color.BLACK)
        }

        // Keep a small black banner slot at the very bottom so the page never jumps
        // when an ad arrives. The slot stays black when AdMob has no fill.
        adContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.VISIBLE
        }

        root.addView(
            webView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        root.addView(
            adContainer,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))
        )

        rootFrame.addView(root, FrameLayout.LayoutParams(-1, -1))
        playerOverlay = FrameLayout(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(12).toFloat()
            }
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
            visibility = View.GONE
            elevation = dp(20).toFloat()
        }
        rootFrame.addView(playerOverlay, FrameLayout.LayoutParams(1, 1))
        setContentView(rootFrame)
        ViewCompat.requestApplyInsets(root)
        webView.loadUrl("file:///android_asset/index.html")

        MobileAds.initialize(this) {
            runOnUiThread { loadBanner() }
        }
    }

    private fun calculatePlayerRect(x: Float, y: Float, width: Float, height: Float): IntArray {
        // JS supplies getBoundingClientRect() coordinates in CSS pixels relative to
        // the WebView viewport. Convert them to rootFrame-local physical pixels.
        val scale = webView.scale
        val webLoc = IntArray(2)
        val rootLoc = IntArray(2)
        webView.getLocationOnScreen(webLoc)
        rootFrame.getLocationOnScreen(rootLoc)
        val left = webLoc[0] - rootLoc[0] + (x * scale).toInt()
        val top = webLoc[1] - rootLoc[1] + (y * scale).toInt()
        val w = (width * scale).toInt().coerceAtLeast(1)
        val h = (height * scale).toInt().coerceAtLeast(1)
        return intArrayOf(left, top, w, h)
    }

    private fun updateInlineVlcPosition(x: Float, y: Float, width: Float, height: Float) {
        if (!::playerOverlay.isInitialized || playerOverlay.visibility != View.VISIBLE || playerFullscreen) return
        if (width <= 0f || height <= 0f) return
        val rect = calculatePlayerRect(x, y, width, height)
        savedPlayerRect = rect

        // During WebView scrolling, move the native VLC overlay using translations.
        // Avoid requesting a full parent layout pass on every scroll frame.
        val currentParams = playerOverlay.layoutParams as? FrameLayout.LayoutParams
        if (currentParams == null) {
            playerOverlay.layoutParams = FrameLayout.LayoutParams(rect[2], rect[3]).apply {
                leftMargin = rect[0]
                topMargin = rect[1]
            }
            playerOverlay.translationX = 0f
            playerOverlay.translationY = 0f
        } else {
            if (currentParams.width != rect[2] || currentParams.height != rect[3]) {
                currentParams.width = rect[2]
                currentParams.height = rect[3]
                playerOverlay.layoutParams = currentParams
            }
            playerOverlay.translationX = (rect[0] - currentParams.leftMargin).toFloat()
            playerOverlay.translationY = (rect[1] - currentParams.topMargin).toFloat()
        }
    }

    private fun showInlineVlc(url: String, title: String, x: Float, y: Float, width: Float, height: Float) {
        stopInlineVlc()
        val rect = calculatePlayerRect(x, y, width, height)
        val left = rect[0]
        val top = rect[1]
        val w = rect[2]
        val h = rect[3]
        savedPlayerRect = rect
        playerFullscreen = false
        playerOverlay.removeAllViews()
        val video = VLCVideoLayout(this); vlcVideo = video
        playerOverlay.addView(video, FrameLayout.LayoutParams(-1, -1))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(6)); setBackgroundColor(0x99000000.toInt()) }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        fun control(label: String, action: () -> Unit) = TextView(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            setPadding(dp(8), dp(6), dp(8), dp(6)); setOnClickListener { action() }
        }
        row.addView(control("−10") { vlcPlayer?.let { it.time = (it.time - 10000).coerceAtLeast(0) } })
        row.addView(control("▶/Ⅱ") { vlcPlayer?.let { if (it.isPlaying) it.pause() else it.play() } })
        row.addView(control("+10") { vlcPlayer?.let { it.time = (it.time + 10000).coerceAtMost(it.length) } })
        playerTime = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; text = "00:00 / 00:00" }
        row.addView(playerTime, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(control("Audio") { showTrackPicker(audio = true) })
        row.addView(control("CC") { showTrackPicker(audio = false) })
        row.addView(control("⛶") { togglePlayerFullscreen() })
        controls.addView(row)
        playerSeek = SeekBar(this).also { bar ->
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(seekBar: SeekBar?) { seekBar?.let { vlcPlayer?.time = it.progress.toLong() }; seeking = false }
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
            })
        }
        controls.addView(playerSeek, LinearLayout.LayoutParams(-1, dp(30)))
        playerOverlay.addView(controls, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        playerOverlay.translationX = 0f
        playerOverlay.translationY = 0f
        playerOverlay.layoutParams = FrameLayout.LayoutParams(w, h).apply { leftMargin = left; topMargin = top }
        playerOverlay.visibility = View.VISIBLE
        try {
            val engine = LibVLC(this, arrayListOf("--network-caching=1500", "--avcodec-hw=any")); vlc = engine
            val mp = MediaPlayer(engine); vlcPlayer = mp
            mp.attachViews(video, null, false, false)
            val media = Media(engine, Uri.parse(url)); mp.media = media; media.release(); mp.play()
            playerHandler.post(playerProgress)
        } catch (e: Exception) {
            Toast.makeText(this, "VLC error: ${e.message}", Toast.LENGTH_LONG).show(); stopInlineVlc()
        }
    }

    private fun showTrackPicker(audio: Boolean) {
        val mp = vlcPlayer ?: return
        try {
            val tracks = if (audio) mp.audioTracks else mp.spuTracks
            if (tracks.isNullOrEmpty()) {
                Toast.makeText(this, if (audio) "No alternate audio tracks" else "No subtitles available", Toast.LENGTH_SHORT).show()
                return
            }
            val labels = tracks.map { it.name ?: "Track ${it.id}" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle(if (audio) "Audio tracks" else "Subtitles")
                .setItems(labels) { _, which ->
                    val trackId = tracks[which].id
                    if (audio) mp.setAudioTrack(trackId) else mp.setSpuTrack(trackId)
                }
                .setNegativeButton("Cancel", null)
                .show()
        } catch (error: Exception) {
            Toast.makeText(this, "Track selection unavailable: ${error.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun applyFullscreenVideoSizing() {
        val overlay = playerOverlay
        val video = vlcVideo
        val mp = vlcPlayer
        if (!::playerOverlay.isInitialized || video == null || mp == null) return

        // VLC scale 0 means fit the video to the available output while preserving
        // the video's aspect ratio (no stretching of faces or picture geometry).
        val reapply = Runnable {
            if (playerFullscreen && vlcPlayer === mp && vlcVideo === video) {
                runCatching {
                    mp.setAspectRatio(null)
                    mp.setScale(0f)
                    video.requestLayout()
                    overlay.requestLayout()
                    video.invalidate()
                }
            }
        }
        overlay.post(reapply)
        overlay.postDelayed(reapply, 250)
        overlay.postDelayed(reapply, 600)
    }

    private fun togglePlayerFullscreen() {
        if (!::playerOverlay.isInitialized || playerOverlay.visibility != View.VISIBLE) return
        if (!playerFullscreen) {
            savedOrientation = requestedOrientation
            playerFullscreen = true
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            playerOverlay.layoutParams = FrameLayout.LayoutParams(-1, -1)
            // Re-apply VLC's fit-to-output sizing after the device has completed rotation.
            // This keeps the source aspect ratio and avoids a small, stale-sized 1080p surface.
            applyFullscreenVideoSizing()
        } else {
            playerFullscreen = false
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            playerOverlay.translationX = 0f
            playerOverlay.translationY = 0f
            playerOverlay.layoutParams = FrameLayout.LayoutParams(savedPlayerRect[2], savedPlayerRect[3]).apply {
                leftMargin = savedPlayerRect[0]; topMargin = savedPlayerRect[1]
            }
        }
    }

    private fun stopInlineVlc() {
        playerHandler.removeCallbacks(playerProgress)
        runCatching { vlcPlayer?.stop(); vlcPlayer?.detachViews(); vlcPlayer?.release() }
        vlcPlayer = null
        runCatching { vlc?.release() }; vlc = null
        if (::playerOverlay.isInitialized) { playerOverlay.removeAllViews(); playerOverlay.visibility = View.GONE }
        if (playerFullscreen) {
            playerFullscreen = false; requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }
    }

    private fun timeText(ms: Long): String {
        val sec = (ms.coerceAtLeast(0L) / 1000); return String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
    }

    private fun handleExternalTelegramLink(url: String): Boolean {
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        val host = uri.host?.lowercase() ?: return false
        if (host != "t.me" && host != "www.t.me" && host != "telegram.me" && host != "www.telegram.me") {
            return false
        }

        val telegramIntent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("org.telegram.messenger")
        }
        try {
            startActivity(telegramIntent)
        } catch (_: ActivityNotFoundException) {
            // If the official Telegram package is unavailable, let Android resolve
            // the same HTTPS channel URL to Telegram X, another Telegram client, or a browser.
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
            } catch (error: ActivityNotFoundException) {
                Log.w("PLAY_MAX", "No app can open Telegram link: $url", error)
            }
        }
        return true
    }

    private fun loadBanner() {
        if (isFinishing || isDestroyed) return

        val screenWidthDp = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()
        val adaptiveAdSize = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, screenWidthDp)
        val adView = AdView(this).apply {
            adUnitId = bannerAdUnitId
            setAdSize(adaptiveAdSize)
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.d("PLAY_MAX_ADS", "Banner loaded")
                    adContainer.visibility = View.VISIBLE
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w("PLAY_MAX_ADS", "Banner failed: ${error.message}")
                    // Keep the reserved black slot; never resize or shift the app on ad failure.
                    adContainer.visibility = View.VISIBLE
                }
            }
        }

        bannerView = adView
        adContainer.removeAllViews()
        // Reserve the exact adaptive banner height at the app's bottom edge.
        // The WebView (including posters, movie details and player) remains above it.
        adContainer.layoutParams = (adContainer.layoutParams as LinearLayout.LayoutParams).apply {
            height = adaptiveAdSize.getHeightInPixels(this@MainActivity)
        }
        adContainer.addView(
            adView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, adaptiveAdSize.getHeightInPixels(this))
        )
        adView.loadAd(AdRequest.Builder().build())
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        // PLAY MAX has only two navigation layers: Home and Movie Details.
        // When Movie Details is open, let its WebView history popstate handler
        // close the whole details page and stop the native VLC overlay together.
        if (customView != null) {
            (window.decorView as? FrameLayout)?.removeView(customView)
            customView = null
            webView.visibility = View.VISIBLE
            adContainer.visibility = View.VISIBLE
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
            requestedOrientation = previousRequestedOrientation
            customViewCallback?.onCustomViewHidden()
            customViewCallback = null
        } else if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else if (::playerOverlay.isInitialized && playerOverlay.visibility == View.VISIBLE) {
            stopInlineVlc()
        } else {
            super.onBackPressed()
        }
    }

    override fun onPause() {
        bannerView?.pause()
        // Stop both audio and video when leaving the app or locking the phone.
        // Keep the MediaPlayer alive so playback can continue from the same position.
        vlcPlayer?.let { mp ->
            runCatching {
                lifecycleWasPlaying = mp.isPlaying
                lifecyclePlaybackTime = mp.time.coerceAtLeast(0L)
                if (mp.isPlaying) mp.pause()
                val video = vlcVideo
                if (video != null) {
                    mp.detachViews()
                    vlcViewsDetachedForPause = true
                }
            }
        }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        bannerView?.resume()
        // Reattach VLC to the visible video surface before resuming audio/video.
        playerOverlay.post {
            val mp = vlcPlayer
            val video = vlcVideo
            if (mp != null && video != null && playerOverlay.visibility == View.VISIBLE) {
                runCatching {
                    if (vlcViewsDetachedForPause) {
                        mp.attachViews(video, null, false, false)
                        vlcViewsDetachedForPause = false
                    }
                    if (lifecycleWasPlaying) {
                        if (lifecyclePlaybackTime > 0L) mp.time = lifecyclePlaybackTime
                        mp.play()
                    }
                }.onFailure {
                    Toast.makeText(this, "Video resume error: ${it.message}", Toast.LENGTH_LONG).show()
                }
            }
            lifecycleWasPlaying = false
        }
    }

    override fun onDestroy() {
        stopInlineVlc()
        bannerView?.destroy()
        bannerView = null
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
