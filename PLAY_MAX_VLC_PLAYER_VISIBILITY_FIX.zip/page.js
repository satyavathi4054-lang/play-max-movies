
    const MOVIES_SPREADSHEET_ID = "1-u-xwuZAyp6rElb0p7jxAxzLSBtCcIXWnJMueaeDPS8";
    const SERIES_SPREADSHEET_ID = "14Kkohl1gNyefw7BzdVTcOOPTOddpYjCVdNbBCGT1Q6I";

    // Method 1: JSONP Loader (100% immune to CORS on mobile file:// and content://)
    function fetchViaJSONP(sheetId, tabName) {
      return new Promise((resolve) => {
        const callbackName = 'gviz_cb_' + Math.random().toString(36).substring(2, 9);
        const script = document.createElement('script');

        const timer = setTimeout(() => {
          cleanup();
          resolve([]);
        }, 4000);

        function cleanup() {
          clearTimeout(timer);
          delete window[callbackName];
          if (script.parentNode) script.parentNode.removeChild(script);
        }

        window[callbackName] = function(data) {
          cleanup();
          try {
            if (!data || !data.table || !data.table.rows) return resolve([]);
            const rows = data.table.rows;
            if (rows.length === 0) return resolve([]);

            const headers = rows[0].c.map(cell => (cell && cell.v ? String(cell.v).toLowerCase().trim() : ''));
            const hasHeaders = headers.includes('title') || headers.includes('poster');

            let colKeys = hasHeaders ? headers : ['title', 'category', 'poster', 'stream_url', 'description', 'rating'];
            let startRow = hasHeaders ? 1 : 0;

            const items = [];
            for (let r = startRow; r < rows.length; r++) {
              const row = rows[r];
              if (!row || !row.c) continue;
              const item = {};
              row.c.forEach((cell, idx) => {
                const key = colKeys[idx] || `col_${idx}`;
                item[key] = (cell && cell.v !== null && cell.v !== undefined) ? String(cell.v).trim() : '';
              });
              if (item.title || item.poster || item.stream_url) {
                items.push(item);
              }
            }
            resolve(items);
          } catch (err) {
            resolve([]);
          }
        };

        script.src = `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=responseHandler:${callbackName}&sheet=${encodeURIComponent(tabName)}`;
        script.onerror = () => {
          cleanup();
          resolve([]);
        };
        document.head.appendChild(script);
      });
    }

    // Method 2: OpenSheet Fetcher with a timeout so a stalled endpoint cannot
    // hold the Home screen indefinitely.
    async function fetchViaOpenSheet(sheetId, tabName) {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6500);
      try {
        const res = await fetch(`https://opensheet.elk.sh/${sheetId}/${encodeURIComponent(tabName)}`, {
          signal: controller.signal,
          cache: 'no-store'
        });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data) && data.length > 0) return data;
        }
      } catch (e) {
        console.warn('OpenSheet request failed; trying Google Sheets fallback:', e);
      } finally {
        clearTimeout(timeoutId);
      }
      return [];
    }

    async function getSheetData(sheetId, tabName) {
      // Try OpenSheet first, then use the existing JSONP fallback if needed.
      const data = await fetchViaOpenSheet(sheetId, tabName);
      if (data && data.length > 0) return data;
      return (await fetchViaJSONP(sheetId, tabName)) || [];
    }

    const player = new Plyr('#netflixPlayer', {
      controls: [
        'play-large', 'play', 'progress', 'current-time', 
        'duration', 'mute', 'volume', 'settings', 'pip', 'fullscreen'
      ],
      settings: ['speed'],
      speed: { selected: 1, options: [0.5, 0.75, 1, 1.25, 1.5, 2] },
      seekTime: 10
    });

    player.on('timeupdate', () => {
      if (window.currentActiveMovie && player.currentTime > 5) {
        saveWatchProgress(window.currentActiveMovie, player.currentTime, player.duration);
      }
    });


        const modal = document.getElementById('videoModal');
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closePlayer();
      }
    });

    let allMoviesData = [];

    // On Android, hand video playback to the native Media3/ExoPlayer engine.
    // Keep the existing Plyr path as the browser fallback.
    function detectBrowserMime(streamUrl) {
      // Do not guess MP4 for extensionless server URLs. Android uses the native
      // Media3 player and can inspect the response headers/container. The browser
      // fallback only declares a MIME type when the URL gives us reliable evidence.
      let path = '';
      try { path = new URL(streamUrl, window.location.href).pathname.toLowerCase(); }
      catch (_) { path = (streamUrl || '').split('?')[0].toLowerCase(); }
      if (path.endsWith('.m3u8')) return 'application/vnd.apple.mpegurl';
      if (path.endsWith('.mpd')) return 'application/dash+xml';
      if (path.endsWith('.mkv')) return 'video/x-matroska';
      if (path.endsWith('.mp4') || path.endsWith('.m4v')) return 'video/mp4';
      if (path.endsWith('.webm')) return 'video/webm';
      return null;
    }

    function setBrowserPlayerSource(streamUrl, title) {
      const source = { src: streamUrl, size: 720 };
      const mime = detectBrowserMime(streamUrl);
      if (mime) source.type = mime;
      player.source = { type: 'video', title: title || 'Play Max', sources: [source] };
    }

    function playWithNativePlayer(streamUrl, title) {
      if (window.PlayMaxPlayer && typeof window.PlayMaxPlayer.play === 'function') {
        if (typeof player !== 'undefined') player.pause();
        window.PlayMaxPlayer.play(streamUrl, title || 'Play Max');
        return true;
      }
      return false;
    }

    function openPlayer(movieOrUrl) {
      if (!movieOrUrl) return;

      let movie = typeof movieOrUrl === 'object' ? movieOrUrl : allMoviesData.find(m => m.stream_url === movieOrUrl);
      if (!movie && typeof movieOrUrl === 'string') {
        movie = { stream_url: movieOrUrl, title: 'Now Playing', description: '', category: 'HD' };
      }

      modal.classList.add('active');
      history.pushState({ playerOpen: true }, '');

      // Populate details below the player
      document.getElementById('modalTitle').textContent = movie.title || 'Movie Stream';
      document.getElementById('modalDescription').textContent = movie.description || 'Watch in high definition streaming with crystal-clear audio.';
      document.getElementById('modalCategoryBadge').textContent = (movie.category || 'HD').split(',')[0].trim();

      // Set IMDb Badge (if user has rating in sheet, show it; else show 8.5)
      const imdbBadge = document.getElementById('modalImdbBadge');
      if (movie.rating || movie.imdb) {
        imdbBadge.textContent = '★ IMDb ' + (movie.rating || movie.imdb);
      } else {
        imdbBadge.textContent = '★ IMDb 8.5';
      }

      // Update My List button state
      updateMyListBtn(movie);

            // Parse Episodes for Web Series
      const epContainer = document.getElementById('episodesContainer');
      const epList = document.getElementById('episodesList');
      epList.innerHTML = '';

      let episodes = [];
      const rawUrl = movie.stream_url || '';

      if (rawUrl.includes('|') || rawUrl.includes('\n')) {
        const parts = rawUrl.split(/[|\n]/).map(p => p.trim()).filter(Boolean);
        parts.forEach((part, index) => {
          if (part.includes(':http')) {
            const splitIdx = part.indexOf(':http');
            const title = part.substring(0, splitIdx).trim();
            const url = part.substring(splitIdx + 1).trim();
            episodes.push({ title: title || `Ep ${index + 1}`, url: url });
          } else {
            episodes.push({ title: `Episode ${index + 1}`, url: part.trim() });
          }
        });
      }

      let activePlayUrl = episodes.length > 0 ? episodes[0].url : rawUrl;

      if (episodes.length > 1) {
        epContainer.style.display = 'block';
        episodes.forEach((ep, idx) => {
          const epBtn = document.createElement('button');
          epBtn.className = `episode-btn ${idx === 0 ? 'active' : ''}`;
          epBtn.innerHTML = `▶ ${ep.title}`;
          epBtn.onclick = () => {
            document.querySelectorAll('.episode-btn').forEach(b => b.classList.remove('active'));
            epBtn.classList.add('active');
            changeEpisode(ep.url, ep.title);
          };
          epList.appendChild(epBtn);
        });
      } else {
        epContainer.style.display = 'none';
      }

      function changeEpisode(streamUrl, epTitle) {
        const nativeStarted = playWithNativePlayer(streamUrl, `${movie.title} - ${epTitle}`);
        if (!nativeStarted) {
          setBrowserPlayerSource(streamUrl, `${movie.title} - ${epTitle}`);
          setTimeout(() => { player.play().catch(e => console.log(e)); }, 150);
        }
        const dlBtn = document.getElementById('modalDownloadBtn');
        if (dlBtn) dlBtn.href = streamUrl;
      }

      // Set Download Link
      const dlBtn = document.getElementById('modalDownloadBtn');
      dlBtn.href = movie.stream_url || '#';

      // Current active movie for sharing
      window.currentActiveMovie = movie;

      // Populate Recommendations inside player
      const recRow = document.getElementById('modalRecRow');
      recRow.innerHTML = '';
      const normalizeTitle = title => (title || '')
  .toLowerCase()
  .replace(/[^a-z0-9]/g, '')
  .trim();

const seenTitles = new Set();

const otherMovies = allMoviesData.filter(m => {
  const key = normalizeTitle(m.title);

  if (!key || key === normalizeTitle(movie.title)) return false;
  if (seenTitles.has(key)) return false;

  seenTitles.add(key);
  return true;
});
      
      otherMovies.slice(0, 10).forEach(other => {
        const rCard = document.createElement('div');
        rCard.className = 'rec-card';
        rCard.title = other.title;
        rCard.onclick = (e) => {
          e.stopPropagation();
          openPlayer(other);
          modal.scrollTo({ top: 0, behavior: 'smooth' });
        };
        rCard.innerHTML = `<img src="${other.poster}" alt="${other.title}" loading="lazy">`;
        recRow.appendChild(rCard);
      });

      const videoElement = document.getElementById('netflixPlayer');
      if (videoElement) videoElement.preload = 'auto';
      const nativeStarted = playWithNativePlayer(activePlayUrl, movie.title || 'Movie Stream');
      if (!nativeStarted) {
        setBrowserPlayerSource(activePlayUrl, movie.title || 'Movie Stream');
        setTimeout(() => {
          player.play().catch(e => console.log('Autoplay handled:', e));
        }, 150);
      }
    }

    function closePlayer() {
      player.pause();
      modal.classList.remove('active');
      player.stop();

      // Clean up browser history state if closing via on-screen button
      if (history.state && history.state.playerOpen) {
        history.back();
      }
    }

    // Handle Phone / Browser Hardware Back Button
    window.addEventListener('popstate', () => {
      if (modal.classList.contains('active')) {
        player.pause();
        modal.classList.remove('active');
        player.stop();
      }
    });

    // Handle ESC key on keyboard
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal.classList.contains('active')) {
        closePlayer();
      }
    });

    // Load data directly from Google Sheets
    async function loadMovies() {
      try {
        // Fetch Movies and Web Series
        const [movies, series] = await Promise.all([
          getSheetData(MOVIES_SPREADSHEET_ID, 'Sheet1'),
          getSheetData(SERIES_SPREADSHEET_ID, 'Sheet1')
        ]);

        series.forEach(s => {
          if (!s.category || !s.category.toLowerCase().includes('series')) {
            s.category = (s.category ? s.category + ', ' : '') + 'Web Series';
          }
        });

        allMoviesData = [...movies, ...series];

        const trendingRow = document.getElementById('trendingRow');
        const teluguRow = document.getElementById('teluguRow');
        const tamilRow = document.getElementById('tamilRow');
        const hindiRow = document.getElementById('hindiRow');
        const englishRow = document.getElementById('englishRow');
        const seriesRow = document.getElementById('seriesRow');
        const allMoviesRow = document.getElementById('allMoviesRow');
        const heroContainer = document.getElementById('heroContainer');

        trendingRow.innerHTML = '';
        teluguRow.innerHTML = '';
        tamilRow.innerHTML = '';
        hindiRow.innerHTML = '';
        englishRow.innerHTML = '';
        if (seriesRow) seriesRow.innerHTML = '';
        allMoviesRow.innerHTML = '';
        heroContainer.innerHTML = '';

        if (!movies || movies.length === 0) return;

        // Build Hero Slides (First 3 movies)
        const heroMovies = movies.slice(0, 3);
        heroMovies.forEach((m, idx) => {
          const slide = document.createElement('div');
          slide.className = `hero-slide ${idx === 0 ? 'active' : ''}`;
          slide.style.backgroundImage = `url('${m.poster}')`;
          slide.innerHTML = `
            <div class="hero-overlay"></div>
            <div class="hero-content">
              <span class="hero-tag">${m.category || 'Featured'}</span>
              <h1 class="hero-title">${m.title}</h1>
              <p class="hero-desc">${m.description || 'Watch now in high quality streaming.'}</p>
              <button class="btn-play" onclick="openPlayer(allMoviesData[${idx}])">
                ▶ Play Now
              </button>
            </div>
          `;
          heroContainer.appendChild(slide);
        });

        // Add Hero Dots
        const dotsContainer = document.createElement('div');
        dotsContainer.className = 'hero-dots';
        heroMovies.forEach((_, idx) => {
          const dot = document.createElement('div');
          dot.className = `dot ${idx === 0 ? 'active' : ''}`;
          dot.onclick = () => goToSlide(idx);
          dotsContainer.appendChild(dot);
        });
        heroContainer.appendChild(dotsContainer);

        // Track counts to hide empty category rows
        let counts = { trending: 0, telugu: 0, tamil: 0, hindi: 0, english: 0, series: 0 };

        // Helper to create card
        function createCard(m) {
          const card = document.createElement('div');
          card.className = 'movie-card';
          card.onclick = () => openPlayer(m);
          const isNew = (m.title && m.title.includes('2026')) || (m.category && m.category.toLowerCase().includes('new'));
          card.innerHTML = `
            ${isNew ? '<span class="badge-new-card">NEW</span>' : ''}
            <img src="${m.poster}" alt="${m.title}" loading="lazy">
          `;
          return card;
        }

        // Categorize movies dynamically
        movies.forEach(m => {
          const cat = (m.category || '').toLowerCase();
          const card = createCard(m);

          if (cat.includes('trend')) {
            counts.trending++;
            const tCard = createCard(m);
            tCard.classList.add('ranked');
            const rankBadge = document.createElement('div');
            rankBadge.className = 'trending-rank-badge';
            rankBadge.textContent = counts.trending;
            tCard.appendChild(rankBadge);
            trendingRow.appendChild(tCard);
          }
          if (cat.includes('telugu')) {
            teluguRow.appendChild(createCard(m));
            counts.telugu++;
          }
          if (cat.includes('tamil')) {
            tamilRow.appendChild(createCard(m));
            counts.tamil++;
          }
          if (cat.includes('hindi')) {
            hindiRow.appendChild(createCard(m));
            counts.hindi++;
          }
          if (cat.includes('english') || cat.includes('hollywood')) {
            englishRow.appendChild(createCard(m));
            counts.english++;
          }

                    if (cat.includes('series') || cat.includes('web series')) {
            if (seriesRow) seriesRow.appendChild(createCard(m));
            counts.series++;
          }
          allMoviesRow.appendChild(card);
        });

        // Hide section headers if no movies are added yet in that language
        if (counts.trending === 0) document.getElementById('trendingSection').style.display = 'none';
        if (counts.telugu === 0) document.getElementById('teluguSection').style.display = 'none';
        if (counts.tamil === 0) document.getElementById('tamilSection').style.display = 'none';
        if (counts.hindi === 0) document.getElementById('hindiSection').style.display = 'none';
        if (counts.english === 0) document.getElementById('englishSection').style.display = 'none';
        if (counts.series === 0 && document.getElementById('seriesSection')) document.getElementById('seriesSection').style.display = 'none';

        initHeroSlider();
        updateMyListUI();
        updateContinueWatchingUI();
      } catch (err) {
        console.error('Error fetching sheet data:', err);
      }
    }

    // Hero Slider Animation
    let currentSlide = 0;
    let slideInterval;

    function initHeroSlider() {
      const slides = document.querySelectorAll('.hero-slide');
      const dots = document.querySelectorAll('.dot');
      if (slides.length <= 1) return;

      window.goToSlide = function(index) {
        slides[currentSlide]?.classList.remove('active');
        dots[currentSlide]?.classList.remove('active');
        currentSlide = index;
        slides[currentSlide]?.classList.add('active');
        dots[currentSlide]?.classList.add('active');
      };

      function nextSlide() {
        const nextIndex = (currentSlide + 1) % slides.length;
        window.goToSlide(nextIndex);
      }

      slideInterval = setInterval(nextSlide, 4500);
    }

    window.addEventListener('scroll', () => {
      const nav = document.getElementById('navbar');
      if (window.scrollY > 50) {
        nav.classList.add('scrolled');
      } else {
        nav.classList.remove('scrolled');
      }
    });

    
    // Use Android's native share chooser inside the app WebView.
    function shareCurrentMovie() {
      const movie = window.currentActiveMovie;
      if (!movie) {
        alert('Please select a movie first.');
        return;
      }
      const movieTitle = movie.title || 'Movie';
      const movieUrl = movie.stream_url || window.location.href;
      const shareText = `🎬 Watch "${movieTitle}" in HD! 🍿
👉 Link: ${movieUrl}`;
      if (window.PlayMaxBridge && typeof window.PlayMaxBridge.share === 'function') {
        window.PlayMaxBridge.share(shareText, movieTitle);
        return;
      }
      if (navigator.share) {
        navigator.share({ title: movieTitle, text: shareText, url: movieUrl }).catch(() => {});
      } else {
        const waUrl = "https://api.whatsapp.com/send?text=" + encodeURIComponent(shareText);
        window.open(waUrl, '_blank');
      }
    }

    // Live search function with Clear Button and "No Results" detection
    function handleSearch(query) {
      const q = (query || '').toLowerCase().trim();
      const clearBtn = document.getElementById('clearSearchBtn');
      if (clearBtn) clearBtn.style.display = q ? 'inline-block' : 'none';

      let visibleCount = 0;
      allMoviesData.forEach((m) => {
        const titleMatch = (m.title || '').toLowerCase().includes(q);
        const catMatch = (m.category || '').toLowerCase().includes(q);
        const shouldShow = (!q || titleMatch || catMatch);
        if (shouldShow) visibleCount++;

        document.querySelectorAll(`.movie-card img[alt="${m.title}"]`).forEach(img => {
          const card = img.closest('.movie-card');
          if (card) card.style.display = shouldShow ? 'block' : 'none';
        });
      });

      const noRes = document.getElementById('noResultsState');
      if (noRes) {
        noRes.style.display = (q && visibleCount === 0) ? 'block' : 'none';
      }
    }

    function clearSearch() {
      const input = document.getElementById('movieSearchInput');
      if (input) {
        input.value = '';
        handleSearch('');
      }
    }

    // Manual Refresh / Sync with Google Sheets
    async function refreshData() {
      const btn = document.getElementById('btnRefresh');
      if (btn) btn.classList.add('spinning');
      await loadMovies();
      setTimeout(() => {
        if (btn) btn.classList.remove('spinning');
        const toast = document.getElementById('appToast');
        if (toast) {
          toast.textContent = 'Data refreshed from Sheets!';
          toast.classList.add('show');
          setTimeout(() => {
            toast.classList.remove('show');
            toast.textContent = 'Press back again to exit';
          }, 2000);
        }
      }, 600);
    }

    
    // -------------------------------------------------------------
    // My List (Watchlist) Management using LocalStorage
    // -------------------------------------------------------------
    function getMyList() {
      try {
        return JSON.parse(localStorage.getItem('myMovieWatchlist')) || [];
      } catch (e) {
        return [];
      }
    }

    function saveMyList(list) {
      localStorage.setItem('myMovieWatchlist', JSON.stringify(list));
      updateMyListUI();
        updateContinueWatchingUI();
    }

    function toggleMyList() {
      const movie = window.currentActiveMovie;
      if (!movie) return;

      let list = getMyList();
      const idx = list.findIndex(m => m.stream_url === movie.stream_url);

      if (idx > -1) {
        // Remove from list
        list.splice(idx, 1);
      } else {
        // Add to list
        list.push(movie);
      }

      saveMyList(list);
      updateMyListBtn(movie);
    }

    function updateMyListBtn(movie) {
      const btn = document.getElementById('modalMyListBtn');
      const icon = document.getElementById('myListIcon');
      const text = document.getElementById('myListText');
      if (!btn || !movie) return;

      const list = getMyList();
      const inList = list.some(m => m.stream_url === movie.stream_url);

      if (inList) {
        btn.classList.add('in-list');
        icon.textContent = '✓';
        text.textContent = 'In My List';
      } else {
        btn.classList.remove('in-list');
        icon.textContent = '+';
        text.textContent = 'My List';
      }
    }

    function updateMyListUI() {
      const list = getMyList();
      const countSpan = document.getElementById('myListCount');
      if (countSpan) countSpan.textContent = list.length;

      const myListSection = document.getElementById('myListSection');
      const myListRow = document.getElementById('myListRow');
      if (!myListSection || !myListRow) return;

      myListRow.innerHTML = '';
      if (list.length === 0) {
        myListSection.style.display = 'none';
        return;
      }

      myListSection.style.display = 'block';
      list.forEach(m => {
        const card = document.createElement('div');
        card.className = 'movie-card';
        card.onclick = () => openPlayer(m);
        card.innerHTML = `<img src="${m.poster}" alt="${m.title}" loading="lazy">`;
        myListRow.appendChild(card);
      });
    }

    // -------------------------------------------------------------
    // Quick Category / Tag Filter Chips
    // -------------------------------------------------------------
    function filterByTag(tag, chipElement) {
      document.querySelectorAll('.filter-chips .chip').forEach(c => c.classList.remove('active'));
      if (chipElement) chipElement.classList.add('active');

      const sections = {
        trending: document.getElementById('trendingSection'),
        telugu: document.getElementById('teluguSection'),
        tamil: document.getElementById('tamilSection'),
        hindi: document.getElementById('hindiSection'),
        english: document.getElementById('englishSection'),
        series: document.getElementById('seriesSection'),
        all: document.getElementById('allSection'),
        mylist: document.getElementById('myListSection')
      };

      if (tag === 'all') {
        Object.keys(sections).forEach(k => {
          if (sections[k]) {
            if (k === 'mylist') {
              sections[k].style.display = getMyList().length > 0 ? 'block' : 'none';
            } else {
              sections[k].style.display = 'block';
            }
          }
        });
        document.querySelectorAll('.movie-card').forEach(c => c.style.display = 'block');
      } else if (tag === 'mylist') {
        Object.keys(sections).forEach(k => {
          if (sections[k]) sections[k].style.display = (k === 'mylist') ? 'block' : 'none';
        });
        if (getMyList().length === 0) {
          alert('Your watchlist is currently empty. Play any movie and tap "+ My List" to add it!');
        }
      } else if (['action', 'comedy', 'thriller'].includes(tag)) {
        // Filter by Genre
        Object.keys(sections).forEach(k => {
          if (sections[k]) sections[k].style.display = (k === 'all') ? 'block' : 'none';
        });
        allMoviesData.forEach(m => {
          const match = (m.description || '' + m.category || '').toLowerCase().includes(tag);
          document.querySelectorAll(`.movie-card img[alt="${m.title}"]`).forEach(img => {
            const card = img.closest('.movie-card');
            if (card) card.style.display = match ? 'block' : 'none';
          });
        });
      } else {
        Object.keys(sections).forEach(k => {
          if (sections[k]) sections[k].style.display = (k === tag) ? 'block' : 'none';
        });
        document.querySelectorAll('.movie-card').forEach(c => c.style.display = 'block');
      }
    }
    // -------------------------------------------------------------
    // Continue Watching Tracking (LocalStorage)
    // -------------------------------------------------------------
    function getWatchHistory() {
      try {
        return JSON.parse(localStorage.getItem('ottWatchHistory')) || {};
      } catch (e) {
        return {};
      }
    }

    function saveWatchProgress(movie, time, duration) {
      if (!movie || !time || time < 5) return;
      const history = getWatchHistory();
      history[movie.stream_url] = {
        movie: movie,
        time: time,
        duration: duration || 0,
        percent: duration > 0 ? Math.min(100, Math.round((time / duration) * 100)) : 0,
        updatedAt: Date.now()
      };
      localStorage.setItem('ottWatchHistory', JSON.stringify(history));
      updateContinueWatchingUI();
    }

    function updateContinueWatchingUI() {
      const history = getWatchHistory();
      const section = document.getElementById('continueWatchingSection');
      const row = document.getElementById('continueWatchingRow');
      if (!section || !row) return;

      const items = Object.values(history).sort((a, b) => b.updatedAt - a.updatedAt);
      if (items.length === 0) {
        section.style.display = 'none';
        return;
      }

      section.style.display = 'block';
      row.innerHTML = '';

      items.forEach(item => {
        const m = item.movie;
        const card = document.createElement('div');
        card.className = 'movie-card';
        card.title = `${m.title} (${item.percent}% watched)`;
        card.onclick = () => {
          openPlayer(m);
          // Resume at saved second
          setTimeout(() => {
            if (player && item.time) player.currentTime = item.time;
          }, 300);
        };

        card.innerHTML = `
          <img src="${m.poster}" alt="${m.title}" loading="lazy">
          <div class="card-progress-bar">
            <div class="card-progress-fill" style="width: ${item.percent}%;"></div>
          </div>
        `;
        row.appendChild(card);
      });
    }

    
    // -------------------------------------------------------------
    // Mobile Bottom Navigation Bar Actions
    // -------------------------------------------------------------
    function bottomNavAction(action) {
      document.querySelectorAll('.bottom-nav .nav-item').forEach(item => item.classList.remove('active'));

      if (action === 'home') {
        document.getElementById('bNavHome').classList.add('active');
        filterByTag('all', document.querySelector('.chip'));
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else if (action === 'search') {
        document.getElementById('bNavSearch').classList.add('active');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        const searchInput = document.getElementById('movieSearchInput');
        if (searchInput) {
          setTimeout(() => {
            searchInput.focus();
            searchInput.select();
          }, 300);
        }
      } else if (action === 'trending') {
        document.getElementById('bNavTrending').classList.add('active');
        const trendingSec = document.getElementById('trendingSection');
        if (trendingSec) {
          trendingSec.style.display = 'block';
          trendingSec.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      } else if (action === 'mylist') {
        document.getElementById('bNavMyList').classList.add('active');
        const myListChip = document.querySelector('.chip-mylist');
        filterByTag('mylist', myListChip);
        const mySec = document.getElementById('myListSection');
        if (mySec) {
          mySec.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }
    }

    
    // -------------------------------------------------------------
    // 1. App Splash Screen Timer
    // -------------------------------------------------------------
    window.addEventListener('load', () => {
      setTimeout(() => {
        const splash = document.getElementById('splashScreen');
        if (splash) splash.classList.add('fade-out');
      }, 1600);
    });

    // -------------------------------------------------------------
    // 2. Double Tap to Seek (±10s) on Video Player
    // -------------------------------------------------------------
    const playerWrapper = document.querySelector('.player-wrapper');
    const seekLeft = document.getElementById('seekLeftRipple');
    const seekRight = document.getElementById('seekRightRipple');
    let lastTapTime = 0;
    let tapTimeout = null;

    if (playerWrapper) {
      playerWrapper.addEventListener('click', (e) => {
        const currentTime = new Date().getTime();
        const tapLength = currentTime - lastTapTime;

        if (tapLength < 350 && tapLength > 50) {
          // Double Tap Detected!
          clearTimeout(tapTimeout);
          const rect = playerWrapper.getBoundingClientRect();
          const clickX = e.clientX - rect.left;
          const isLeft = clickX < (rect.width / 2);

          if (isLeft) {
            // Seek Backwards 10s
            player.currentTime = Math.max(0, player.currentTime - 10);
            triggerRipple(seekLeft);
          } else {
            // Seek Forward 10s
            player.currentTime = Math.min(player.duration || 9999, player.currentTime + 10);
            triggerRipple(seekRight);
          }
        }
        lastTapTime = currentTime;
      });
    }

    function triggerRipple(elem) {
      if (!elem) return;
      elem.classList.remove('show');
      void elem.offsetWidth; // force reflow
      elem.classList.add('show');
      setTimeout(() => elem.classList.remove('show'), 550);
    }

    // -------------------------------------------------------------
    // 3. Auto Fullscreen on Device Rotation (Landscape)
    // -------------------------------------------------------------
    window.addEventListener('orientationchange', () => {
      if (modal.classList.contains('active')) {
        if (window.orientation === 90 || window.orientation === -90) {
          // Landscape: Enter Fullscreen
          if (player && player.fullscreen && !player.fullscreen.active) {
            player.fullscreen.enter();
          }
        } else if (window.orientation === 0 || window.orientation === 180) {
          // Portrait: Exit Fullscreen
          if (player && player.fullscreen && player.fullscreen.active) {
            player.fullscreen.exit();
          }
        }
      }
    });

    // -------------------------------------------------------------
    // 4. Double Back to Exit App Prevention
    // -------------------------------------------------------------
    let lastBackPressTime = 0;
    const toast = document.getElementById('appToast');

    window.addEventListener('popstate', (e) => {
      // If modal was open, back closes modal (already handled)
      if (modal.classList.contains('active')) {
        return;
      }

      // If at home, require double back within 2 seconds
      const now = Date.now();
      if (now - lastBackPressTime < 2000) {
        // Allow exit
        return;
      }

      // Prevent immediate close, show toast
      lastBackPressTime = now;
      history.pushState(null, '', window.location.href);
      if (toast) {
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2000);
      }
    });

    // Push initial history entry to catch first back press
    history.pushState(null, '', window.location.href);
// Network Online / Offline Detection
    window.addEventListener('offline', () => {
      const b = document.getElementById('offlineBanner');
      if (b) b.style.display = 'block';
    });
    window.addEventListener('online', () => {
      const b = document.getElementById('offlineBanner');
      if (b) b.style.display = 'none';
    });

    
    // -------------------------------------------------------------
    // Player Gestures: Vertical Swipe for Brightness & Volume
    // -------------------------------------------------------------
    let touchStartY = 0;
    let touchStartX = 0;
    let currentBrightness = 1.0;
    const brightnessHud = document.getElementById('brightnessHud');
    const brightnessFill = document.getElementById('brightnessFill');
    const brightnessText = document.getElementById('brightnessText');
    const brightnessShade = document.getElementById('brightnessShade');
    const volumeHud = document.getElementById('volumeHud');
    const volumeFill = document.getElementById('volumeFill');
    const volumeText = document.getElementById('volumeText');

    if (playerWrapper) {
      playerWrapper.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) {
          touchStartY = e.touches[0].clientY;
          touchStartX = e.touches[0].clientX;
        }
      }, { passive: true });

      playerWrapper.addEventListener('touchmove', (e) => {
        if (e.touches.length === 1) {
          const deltaY = touchStartY - e.touches[0].clientY;
          const rect = playerWrapper.getBoundingClientRect();
          const isLeft = (touchStartX - rect.left) < (rect.width / 2);

          if (Math.abs(deltaY) > 15) {
            if (isLeft) {
              // Adjust Brightness
              currentBrightness = Math.min(1.0, Math.max(0.15, currentBrightness + (deltaY > 0 ? 0.02 : -0.02)));
              if (brightnessShade) brightnessShade.style.opacity = (1 - currentBrightness);
              if (brightnessFill) brightnessFill.style.width = Math.round(currentBrightness * 100) + '%';
              if (brightnessText) brightnessText.textContent = Math.round(currentBrightness * 100) + '%';
              if (brightnessHud) {
                brightnessHud.classList.add('show');
                clearTimeout(window.bHudTimer);
                window.bHudTimer = setTimeout(() => brightnessHud.classList.remove('show'), 700);
              }
            } else {
              // Adjust Volume
              if (player) {
                const newVol = Math.min(1.0, Math.max(0.0, player.volume + (deltaY > 0 ? 0.03 : -0.03)));
                player.volume = newVol;
                if (volumeFill) volumeFill.style.width = Math.round(newVol * 100) + '%';
                if (volumeText) volumeText.textContent = Math.round(newVol * 100) + '%';
                if (volumeHud) {
                  volumeHud.classList.add('show');
                  clearTimeout(window.vHudTimer);
                  window.vHudTimer = setTimeout(() => volumeHud.classList.remove('show'), 700);
                }
              }
            }
            touchStartY = e.touches[0].clientY;
          }
        }
      }, { passive: true });
    }



    window.onload = loadMovies;
  