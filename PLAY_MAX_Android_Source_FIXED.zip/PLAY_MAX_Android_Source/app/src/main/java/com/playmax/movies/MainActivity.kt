package com.playmax.movies

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.libraries.ads.mobile.sdk.MobileAds
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig
import com.google.android.libraries.ads.mobile.sdk.banner.AdView
import com.google.android.libraries.ads.mobile.sdk.banner.AdSize
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAdRequest
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAd
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var adContainer: FrameLayout
    private var bannerView: AdView? = null

    // AdMob App ID provided for PLAY MAX.
    private val admobAppId = "ca-app-pub-1802093280158632~5562890157"

    // Google's official test banner ID. Keep test ads during development.
    // Replace with your real banner unit only after app testing and policy checks.
    private val bannerAdUnitId = "ca-app-pub-3940256099942544/9214589741"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadsImagesAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        adContainer = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
        }

        root.addView(webView, android.widget.LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        root.addView(adContainer, android.widget.LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        setContentView(root)

        webView.loadUrl("file:///android_asset/index.html")

        Thread {
            try {
                MobileAds.initialize(
                    this,
                    InitializationConfig.Builder(admobAppId).build()
                ) {
                    runOnUiThread { loadTestBanner() }
                }
            } catch (e: Exception) {
                Log.e("PLAY_MAX_ADS", "AdMob initialization failed", e)
            }
        }.start()
    }

    private fun loadTestBanner() {
        try {
            val widthDp = (resources.displayMetrics.widthPixels /
                resources.displayMetrics.density).roundToInt()
            val adSize = AdSize.getLargeAnchoredAdaptiveBannerAdSize(this, widthDp)
            val adView = AdView(this)
            bannerView = adView
            val request = BannerAdRequest.Builder(bannerAdUnitId, adSize).build()
            adView.loadAd(request, object : AdLoadCallback<BannerAd> {
                override fun onAdLoaded(ad: BannerAd) {
                    runOnUiThread {
                        adContainer.removeAllViews()
                        adContainer.addView(adView)
                    }
                }
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.w("PLAY_MAX_ADS", "Banner failed: $adError")
                }
            })
        } catch (e: Exception) {
            Log.e("PLAY_MAX_ADS", "Banner setup failed", e)
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        bannerView?.destroy()
        if (::webView.isInitialized) {
            webView.destroy()
        }
        super.onDestroy()
    }
}
