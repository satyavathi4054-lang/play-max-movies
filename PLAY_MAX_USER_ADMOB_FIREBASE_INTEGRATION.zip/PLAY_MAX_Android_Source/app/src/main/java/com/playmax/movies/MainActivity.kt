package com.playmax.movies

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.BitmapFactory
import android.content.ClipData
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.SeekBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.Locale
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import kotlin.concurrent.thread
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var adContainer: FrameLayout
    private var bannerView: AdView? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var previousRequestedOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private var appRoot: LinearLayout? = null
    private lateinit var rootFrame: FrameLayout
    private lateinit var playerOverlay: FrameLayout
    private var vlc: LibVLC? = null
    private var vlcPlayer: MediaPlayer? = null
    private var vlcVideo: VLCVideoLayout? = null
    private var playerFullscreen = false
    private var savedPlayerRect = intArrayOf(0, 0, 0, 0)
    // Remember the active movie so it can be recreated after returning from an external download app.
    private var lastPlaybackUrl: String = ""
    private var lastProgressPersistAt: Long = 0L
    private var suppressWatchPromptOnce: Boolean = false
    private var lastPlaybackTitle: String = "Play Max"
    private var lastPlaybackX: Float = 0f
    private var lastPlaybackY: Float = 0f
    private var lastPlaybackWidth: Float = 0f
    private var lastPlaybackHeight: Float = 0f
    private var resumeAfterExternalDownload: Boolean = false
    private var externalDownloadResumePosition: Long = 0L
    // Prevent Play/Pause taps from racing the saved-position restore after returning from Download.
    private var restoringExternalDownloadPlayback: Boolean = false
    private var savedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    private val playerHandler = Handler(Looper.getMainLooper())
    private var playerSeek: SeekBar? = null
    private var playerTime: TextView? = null
    private var playerPlayPause: TextView? = null
    private var playerControlsContainer: View? = null
    private var playerControlsVisible = true
    private var playerControlsHideScheduled = false
    private val hidePlayerControlsRunnable = Runnable {
        playerControlsHideScheduled = false
        hidePlayerControlsIfPlaying()
    }
    private var seeking = false
    // Preserve VLC playback position/state while the app is backgrounded or the screen is locked.
    private var lifecyclePlaybackTime: Long = 0L
    private var lifecycleWasPlaying: Boolean = false
    // Sharing to another app must pause playback and must not auto-resume on return.
    private var shareInProgress: Boolean = false
    // Tracks playback intent independently of VLC isPlaying, which can be false while buffering.
    private var playbackRequested: Boolean = false
    private var activityInForeground: Boolean = false
    private var vlcViewsDetachedForPause: Boolean = false
    private var lastVlcTime: Long = 0L
    private var lastVlcProgressAt: Long = 0L
    private var vlcRecoveryAttempts: Int = 0
    private fun watchProgressKey(url: String): String = "watch_${url.hashCode()}"

    private fun savedWatchPosition(url: String): Long =
        getSharedPreferences("play_max_watch_progress", MODE_PRIVATE)
            .getLong(watchProgressKey(url), 0L).coerceAtLeast(0L)

    private fun saveWatchPosition(url: String, position: Long, duration: Long = 0L) {
        if (url.isBlank()) return
        val prefs = getSharedPreferences("play_max_watch_progress", MODE_PRIVATE)
        val safePosition = position.coerceAtLeast(0L)
        if (duration > 0L && safePosition >= duration - 60_000L) {
            prefs.edit().remove(watchProgressKey(url)).apply()
        } else if (safePosition >= 10_000L) {
            prefs.edit().putLong(watchProgressKey(url), safePosition).apply()
        }
    }

    private fun offerWatchResume(mp: MediaPlayer, url: String) {
        val saved = savedWatchPosition(url)
        if (saved < 15_000L || suppressWatchPromptOnce) {
            suppressWatchPromptOnce = false
            return
        }
        mp.pause()
        playbackRequested = false
        updateKeepScreenOn()
        android.app.AlertDialog.Builder(this)
            .setTitle("Continue Watching?")
            .setMessage("Resume from ${timeText(saved)} or start this movie from the beginning?")
            .setPositiveButton("Resume") { _, _ ->
                if (vlcPlayer === mp) {
                    mp.time = if (mp.length > 0L) saved.coerceAtMost((mp.length - 1L).coerceAtLeast(0L)) else saved
                    playbackRequested = true
                    updateKeepScreenOn()
                    mp.play()
                    playerPlayPause?.text = "Ⅱ"
                    schedulePlayerControlsAutoHide()
                }
            }
            .setNegativeButton("Start Over") { _, _ ->
                if (vlcPlayer === mp) {
                    saveWatchPosition(url, 0L)
                    mp.time = 0L
                    playbackRequested = true
                    updateKeepScreenOn()
                    mp.play()
                    playerPlayPause?.text = "Ⅱ"
                    schedulePlayerControlsAutoHide()
                }
            }
            .setOnCancelListener {
                if (vlcPlayer === mp) {
                    playbackRequested = true
                    updateKeepScreenOn()
                    mp.play()
                }
            }
            .show()
    }

    private val playerProgress = object : Runnable {
        override fun run() {
            val mp = vlcPlayer
            val bar = playerSeek
            if (mp != null && bar != null && !seeking) {
                val len = mp.length.coerceAtLeast(1L)
                bar.max = len.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                bar.progress = mp.time.coerceIn(0L, len).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                playerTime?.text = "${timeText(mp.time)} / ${timeText(mp.length)}"
                playerPlayPause?.text = if (playbackRequested) "Ⅱ" else "▶"
                val now = SystemClock.elapsedRealtime()
                if (now - lastProgressPersistAt >= 5000L && lastPlaybackUrl.isNotBlank()) {
                    saveWatchPosition(lastPlaybackUrl, mp.time, mp.length)
                    lastProgressPersistAt = now
                }
                val currentTime = mp.time.coerceAtLeast(0L)
                if (currentTime > lastVlcTime + 500L) {
                    lastVlcTime = currentTime
                    lastVlcProgressAt = now
                    vlcRecoveryAttempts = 0
                } else if (playbackRequested && !seeking &&
                    (mp.length <= 0L || currentTime < mp.length - 1000L) &&
                    lastVlcProgressAt > 0L && now - lastVlcProgressAt >= 15000L && vlcRecoveryAttempts < 2) {
                    // Recover a stalled VLC pipeline without leaving the details page.
                    vlcRecoveryAttempts++
                    lastVlcProgressAt = now
                    Log.w("PLAY_MAX_VLC", "Playback stalled; requesting VLC recovery ${vlcRecoveryAttempts}/2")
                    runCatching {
                        if (mp.isPlaying) mp.pause()
                        playerHandler.postDelayed({
                            if (vlcPlayer === mp && playbackRequested && playerOverlay.visibility == View.VISIBLE) {
                                runCatching { mp.play() }
                            }
                        }, 350L)
                    }.onFailure { Log.e("PLAY_MAX_VLC", "VLC recovery request failed", it) }
                }
                if (mp.isPlaying && playerControlsVisible && !playerControlsHideScheduled) {
                    schedulePlayerControlsAutoHide()
                }
                if (!mp.isPlaying && playerControlsVisible.not()) showPlayerControls()
            }
            if (vlcPlayer != null) playerHandler.postDelayed(this, 500)
        }
    }

    // AdMob IDs are loaded from Firestore adminSettings/appConfig.
    private var bannerAdUnitId: String = ""
    private var interstitialAdUnitId: String = ""
    private var admobPublisherId: String = ""
    private var interstitialAd: InterstitialAd? = null

    private fun loadAdMobSettingsFromFirebase() {
        FirebaseFirestore.getInstance()
            .collection("adminSettings").document("appConfig")
            .get()
            .addOnSuccessListener { snapshot ->
                if (!snapshot.exists()) {
                    Log.w("PLAY_MAX_ADS", "Firestore adminSettings/appConfig does not exist")
                    return@addOnSuccessListener
                }
                bannerAdUnitId = snapshot.getString("admobBannerAdUnitId").orEmpty().trim()
                interstitialAdUnitId = snapshot.getString("admobInterstitialAdUnitId").orEmpty().trim()
                admobPublisherId = snapshot.getString("admobPublisherId").orEmpty().trim()
                Log.d("PLAY_MAX_ADS", "AdMob settings loaded from Firestore; banner configured=${bannerAdUnitId.isNotBlank()}, interstitial configured=${interstitialAdUnitId.isNotBlank()}")
                if (bannerAdUnitId.isNotBlank()) loadBanner() else {
                    adContainer.removeAllViews()
                    adContainer.visibility = View.GONE
                }
                if (interstitialAdUnitId.isNotBlank()) loadInterstitialAd()
            }
            .addOnFailureListener { error ->
                Log.e("PLAY_MAX_ADS", "Could not load AdMob settings from Firestore", error)
            }
    }

    private fun loadInterstitialAd() {
        val unitId = interstitialAdUnitId
        if (unitId.isBlank() || isFinishing || isDestroyed) return
        InterstitialAd.load(this, unitId, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    Log.d("PLAY_MAX_ADS", "Interstitial ad loaded")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    Log.w("PLAY_MAX_ADS", "Interstitial failed to load: ${error.message}")
                }
            })
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    // Keep the display awake only while VLC playback is actively requested and this Activity is visible.
    private fun updateKeepScreenOn() {
        val shouldKeepAwake = activityInForeground && playbackRequested &&
            ::playerOverlay.isInitialized && playerOverlay.visibility == View.VISIBLE &&
            !isFinishing && !isDestroyed
        if (shouldKeepAwake) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private inner class PlayMaxShareBridge {
        @JavascriptInterface
        fun share(text: String, title: String, posterUrl: String) {
            // Pause immediately before launching the Android Sharesheet so audio never
            // continues underneath WhatsApp or another receiving app.
            runOnUiThread {
                shareInProgress = true
                lifecycleWasPlaying = false
                playbackRequested = false
                updateKeepScreenOn()
                vlcPlayer?.let { mp -> runCatching { mp.pause() } }
                playerPlayPause?.text = "▶"
            }
            // Fetch the movie's own poster off the UI thread, then share image + title + APK link.
            thread(name = "playmax-share-poster") {
                val posterFile = runCatching {
                    if (posterUrl.isBlank()) return@runCatching null
                    val connection = URL(posterUrl).openConnection().apply {
                        connectTimeout = 8000
                        readTimeout = 10000
                    }
                    connection.getInputStream().use { input ->
                        val bitmap = BitmapFactory.decodeStream(input) ?: return@runCatching null
                        val file = File(cacheDir, "playmax_share_poster.jpg")
                        FileOutputStream(file).use { output ->
                            bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, output)
                        }
                        bitmap.recycle()
                        file
                    }
                }.getOrNull()

                runOnUiThread {
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        putExtra(Intent.EXTRA_SUBJECT, title)
                        putExtra(Intent.EXTRA_TEXT, text)
                        if (posterFile != null && posterFile.exists()) {
                            val imageUri = FileProvider.getUriForFile(
                                this@MainActivity,
                                applicationContext.packageName + ".fileprovider",
                                posterFile
                            )
                            type = "image/jpeg"
                            putExtra(Intent.EXTRA_STREAM, imageUri)
                            clipData = ClipData.newUri(contentResolver, "PLAY MAX movie poster", imageUri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        } else {
                            type = "text/plain"
                        }
                    }
                    startActivity(Intent.createChooser(sendIntent, "Share with"))
                }
            }
        }
    }

    private inner class PlayMaxPlayerBridge {
        @JavascriptInterface
        fun play(url: String, title: String, x: Float, y: Float, width: Float, height: Float) {
            if (url.isBlank()) return
            runOnUiThread { showInlineVlc(url, title, x, y, width, height) }
        }
        @JavascriptInterface fun updatePosition(x: Float, y: Float, width: Float, height: Float) {
            runOnUiThread { updateInlineVlcPosition(x, y, width, height) }
        }
        @JavascriptInterface fun stop() { runOnUiThread { stopInlineVlc() } }

        @JavascriptInterface
        fun openDownload(url: String) {
            if (url.isBlank()) return
            val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return
            if (uri.scheme != "http" && uri.scheme != "https") return
            runOnUiThread {
                // Stop the stream while the external download page is open, but retain
                // the movie and its position so the native VLC surface can be recreated
                // when the user returns to this Activity.
                resumeAfterExternalDownload = lastPlaybackUrl.isNotBlank()
                externalDownloadResumePosition = runCatching { vlcPlayer?.time ?: 0L }.getOrDefault(0L)
                restoringExternalDownloadPlayback = resumeAfterExternalDownload
                stopInlineVlc()
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
                } catch (error: ActivityNotFoundException) {
                    resumeAfterExternalDownload = false
                    webView.evaluateJavascript("window.resetPlayMaxDownloadButton && window.resetPlayMaxDownloadButton();", null)
                    Toast.makeText(this@MainActivity, "No app can open this download link", Toast.LENGTH_LONG).show()
                }
            }
        }
    }


    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        rootFrame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }
        appRoot = root

        // Apply system insets once only, preventing duplicate top/bottom offsets in WebView.
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val safeBars = insets.getInsets(
                WindowInsetsCompat.Type.statusBars() or
                    WindowInsetsCompat.Type.navigationBars() or
                    WindowInsetsCompat.Type.displayCutout()
            )
            view.setPadding(safeBars.left, safeBars.top, safeBars.right, safeBars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadsImagesAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    if (::playerOverlay.isInitialized && playerOverlay.visibility == View.VISIBLE) {
            stopInlineVlc()
        } else if (customView != null) {
                        callback.onCustomViewHidden()
                        return
                    }

                    customView = view
                    customViewCallback = callback
                    previousRequestedOrientation = requestedOrientation
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

                    (window.decorView as? FrameLayout)?.addView(
                        view,
                        FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            Gravity.CENTER
                        )
                    )
                    webView.visibility = View.GONE
                    adContainer.visibility = View.GONE
                    window.addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
                }

                override fun onHideCustomView() {
                    val view = customView ?: return
                    (window.decorView as? FrameLayout)?.removeView(view)
                    customView = null
                    webView.visibility = View.VISIBLE
                    adContainer.visibility = View.VISIBLE
                    window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
                    requestedOrientation = previousRequestedOrientation
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                }
            }
            addJavascriptInterface(PlayMaxShareBridge(), "PlayMaxBridge")
            addJavascriptInterface(PlayMaxPlayerBridge(), "PlayMaxPlayer")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest
                ): Boolean = handleExternalTelegramLink(request.url.toString())

                @Suppress("DEPRECATION")
                override fun shouldOverrideUrlLoading(view: WebView?, url: String): Boolean =
                    handleExternalTelegramLink(url)
            }
            setBackgroundColor(Color.BLACK)
        }

        // Keep a small black banner slot at the very bottom so the page never jumps
        // when an ad arrives. The slot stays black when AdMob has no fill.
        adContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.VISIBLE
        }

        root.addView(
            webView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        root.addView(
            adContainer,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))
        )

        rootFrame.addView(root, FrameLayout.LayoutParams(-1, -1))
        playerOverlay = FrameLayout(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(12).toFloat()
            }
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
            visibility = View.GONE
            elevation = dp(20).toFloat()
        }
        rootFrame.addView(playerOverlay, FrameLayout.LayoutParams(1, 1))
        setContentView(rootFrame)
        ViewCompat.requestApplyInsets(root)
        webView.loadUrl("file:///android_asset/index.html")

        MobileAds.initialize(this) {
            runOnUiThread { loadAdMobSettingsFromFirebase() }
        }
    }

    private fun calculatePlayerRect(x: Float, y: Float, width: Float, height: Float): IntArray {
        // JS supplies getBoundingClientRect() coordinates in CSS pixels relative to
        // the WebView viewport. Convert them to rootFrame-local physical pixels.
        val scale = webView.scale
        val webLoc = IntArray(2)
        val rootLoc = IntArray(2)
        webView.getLocationOnScreen(webLoc)
        rootFrame.getLocationOnScreen(rootLoc)
        val left = webLoc[0] - rootLoc[0] + (x * scale).toInt()
        val top = webLoc[1] - rootLoc[1] + (y * scale).toInt()
        val w = (width * scale).toInt().coerceAtLeast(1)
        val h = (height * scale).toInt().coerceAtLeast(1)
        return intArrayOf(left, top, w, h)
    }

    private fun updateInlineVlcPosition(x: Float, y: Float, width: Float, height: Float) {
        if (!::playerOverlay.isInitialized || playerOverlay.visibility != View.VISIBLE || playerFullscreen) return
        if (width <= 0f || height <= 0f) return
        val rect = calculatePlayerRect(x, y, width, height)
        savedPlayerRect = rect

        // During WebView scrolling, move the native VLC overlay using translations.
        // Avoid requesting a full parent layout pass on every scroll frame.
        val currentParams = playerOverlay.layoutParams as? FrameLayout.LayoutParams
        if (currentParams == null) {
            playerOverlay.layoutParams = FrameLayout.LayoutParams(rect[2], rect[3]).apply {
                leftMargin = rect[0]
                topMargin = rect[1]
            }
            playerOverlay.translationX = 0f
            playerOverlay.translationY = 0f
        } else {
            if (currentParams.width != rect[2] || currentParams.height != rect[3]) {
                currentParams.width = rect[2]
                currentParams.height = rect[3]
                playerOverlay.layoutParams = currentParams
            }
            playerOverlay.translationX = (rect[0] - currentParams.leftMargin).toFloat()
            playerOverlay.translationY = (rect[1] - currentParams.topMargin).toFloat()
        }
    }

    private fun showPlayerControls() {
        playerHandler.removeCallbacks(hidePlayerControlsRunnable)
        playerControlsHideScheduled = false
        playerControlsVisible = true
        playerControlsContainer?.visibility = View.VISIBLE
        playerPlayPause?.visibility = View.VISIBLE
    }

    private fun hidePlayerControlsIfPlaying() {
        if (vlcPlayer?.isPlaying == true && !seeking) {
            playerControlsVisible = false
            playerControlsContainer?.visibility = View.GONE
            playerPlayPause?.visibility = View.GONE
        }
    }

    private fun schedulePlayerControlsAutoHide() {
        playerHandler.removeCallbacks(hidePlayerControlsRunnable)
        playerControlsHideScheduled = false
        if (vlcPlayer?.isPlaying == true) {
            playerControlsHideScheduled = true
            playerHandler.postDelayed(hidePlayerControlsRunnable, 3000)
        } else {
            showPlayerControls()
        }
    }

    private fun togglePlayerControlsVisibility() {
        if (playerControlsVisible) {
            playerHandler.removeCallbacks(hidePlayerControlsRunnable)
            playerControlsVisible = false
            playerControlsContainer?.visibility = View.GONE
            playerPlayPause?.visibility = View.GONE
        } else {
            showPlayerControls()
            schedulePlayerControlsAutoHide()
        }
    }

    private fun showInlineVlc(url: String, title: String, x: Float, y: Float, width: Float, height: Float) {
        // Persist the previous movie under its own URL before switching to another movie.
        stopInlineVlc()
        lastPlaybackUrl = url
        lastPlaybackTitle = title
        lastPlaybackX = x
        lastPlaybackY = y
        lastPlaybackWidth = width
        lastPlaybackHeight = height
        val rect = calculatePlayerRect(x, y, width, height)
        val left = rect[0]
        val top = rect[1]
        val w = rect[2]
        val h = rect[3]
        savedPlayerRect = rect
        playerFullscreen = false
        lastVlcTime = 0L
        lastVlcProgressAt = SystemClock.elapsedRealtime()
        vlcRecoveryAttempts = 0
        playerOverlay.removeAllViews()
        val video = VLCVideoLayout(this); vlcVideo = video
        // Re-apply VLC sizing only after the actual video output view receives
        // its new landscape dimensions. The orientation request itself is asynchronous.
        video.addOnLayoutChangeListener { view, left, top, right, bottom,
                                          oldLeft, oldTop, oldRight, oldBottom ->
            val newWidth = right - left
            val newHeight = bottom - top
            val oldWidth = oldRight - oldLeft
            val oldHeight = oldBottom - oldTop
            if (playerFullscreen && newWidth > 0 && newHeight > 0 &&
                (newWidth != oldWidth || newHeight != oldHeight)) {
                view.post { applyFullscreenVideoSizing() }
            }
        }
        playerOverlay.addView(video, FrameLayout.LayoutParams(-1, -1))

        // Transparent tap layer: one tap shows/hides the complete VLC control set.
        val controlTapLayer = View(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            setOnClickListener { togglePlayerControlsVisibility() }
        }
        playerOverlay.addView(controlTapLayer, FrameLayout.LayoutParams(-1, -1))

        // Video watermark intentionally removed per user request.

        val controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(6)); setBackgroundColor(0x99000000.toInt()) }
        playerControlsContainer = controls
        playerControlsVisible = true
        playerControlsHideScheduled = false
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        fun control(label: String, action: () -> Unit) = TextView(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            setPadding(dp(8), dp(6), dp(8), dp(6)); setOnClickListener { action() }
        }
        row.addView(control("−10") { vlcPlayer?.let { it.time = (it.time - 10000).coerceAtLeast(0) } })
        row.addView(control("+10") { vlcPlayer?.let { it.time = (it.time + 10000).coerceAtMost(it.length) } })
        playerTime = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; text = "00:00 / 00:00" }
        row.addView(playerTime, LinearLayout.LayoutParams(0, -2, 1f))
        val audioControl = control("Audio") { }
        var audioDownY = 0f
        var audioGestureMoved = false
        audioControl.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    audioDownY = event.rawY
                    audioGestureMoved = false
                    true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val delta = audioDownY - event.rawY
                    if (kotlin.math.abs(delta) >= dp(12)) {
                        audioGestureMoved = true
                        val steps = (delta / dp(12)).toInt()
                        if (steps != 0) {
                            val mp = vlcPlayer
                            if (mp != null) {
                                mp.volume = (mp.volume + steps * 5).coerceIn(0, 200)
                                Toast.makeText(this, "Volume ${mp.volume}%", Toast.LENGTH_SHORT).show()
                            }
                            audioDownY = event.rawY
                        }
                    }
                    true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    if (!audioGestureMoved) showTrackPicker()
                    view.performClick()
                    true
                }
                android.view.MotionEvent.ACTION_CANCEL -> true
                else -> true
            }
        }
        row.addView(audioControl)
        row.addView(control("⛶") { togglePlayerFullscreen() })
        controls.addView(row)
        playerSeek = SeekBar(this).also { bar ->
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(seekBar: SeekBar?) { seekBar?.let { vlcPlayer?.time = it.progress.toLong() }; seeking = false }
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
            })
        }
        controls.addView(playerSeek, LinearLayout.LayoutParams(-1, dp(30)))
        playerOverlay.addView(controls, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        // Prominent Play/Pause control centered over the video surface.
        // Playback state is refreshed by the existing progress timer.
        playerPlayPause = TextView(this).apply {
            text = "Ⅱ"
            setTextColor(Color.WHITE)
            textSize = 28f
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0x99000000.toInt())
                setStroke(dp(1), 0x66FFFFFF)
            }
            elevation = dp(8).toFloat()
            setOnClickListener {
                if (restoringExternalDownloadPlayback) {
                    Toast.makeText(this@MainActivity, "Restoring previous playback position…", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                vlcPlayer?.let { mp ->
                    if (playbackRequested) {
                        playbackRequested = false
                        updateKeepScreenOn()
                        mp.pause()
                        showPlayerControls()
                    } else {
                        playbackRequested = true
                        updateKeepScreenOn()
                        mp.play()
                        schedulePlayerControlsAutoHide()
                    }
                    text = if (playbackRequested) "Ⅱ" else "▶"
                }
            }
        }
        playerOverlay.addView(
            playerPlayPause,
            FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER)
        )
        showPlayerControls()
        playerOverlay.translationX = 0f
        playerOverlay.translationY = 0f
        playerOverlay.layoutParams = FrameLayout.LayoutParams(w, h).apply { leftMargin = left; topMargin = top }
        playerOverlay.visibility = View.VISIBLE
        try {
            val engine = LibVLC(this, arrayListOf("--network-caching=1200", "--avcodec-hw=any", "--no-spu", "--freetype-rel-fontsize=12")); vlc = engine
            val mp = MediaPlayer(engine); vlcPlayer = mp
            mp.attachViews(video, null, false, false)
            val media = Media(engine, Uri.parse(url)); mp.media = media; media.release()
            playbackRequested = true
            updateKeepScreenOn()
            mp.play()
            playerHandler.post(playerProgress)
            val shouldOfferResume = !suppressWatchPromptOnce && savedWatchPosition(url) >= 15_000L
            if (shouldOfferResume) {
                fun waitForMovieInfo(attempt: Int) {
                    if (vlcPlayer !== mp || isFinishing || isDestroyed) return
                    if (mp.length > 0L || attempt >= 20) {
                        if (mp.length > 0L) offerWatchResume(mp, url)
                    } else {
                        playerHandler.postDelayed({ waitForMovieInfo(attempt + 1) }, 250L)
                    }
                }
                playerHandler.post { waitForMovieInfo(0) }
            } else {
                suppressWatchPromptOnce = false
            }
        } catch (e: Exception) {
            Toast.makeText(this, "VLC error: ${e.message}", Toast.LENGTH_LONG).show(); stopInlineVlc()
        }
    }

    private fun showTrackPicker() {
        val mp = vlcPlayer ?: return
        try {
            val audioTracks = mp.audioTracks
            if (audioTracks.isNullOrEmpty()) {
                Toast.makeText(this, "No alternate audio tracks available", Toast.LENGTH_SHORT).show()
                return
            }

            playerOverlay.findViewWithTag<View>("playmax_track_panel")?.let { playerOverlay.removeView(it) }
            val dim = FrameLayout(this).apply {
                tag = "playmax_track_panel"
                setBackgroundColor(0x77000000)
                isClickable = true
            }
            val panel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(18))
                setBackground(android.graphics.drawable.GradientDrawable().apply {
                    setColor(0xFF17191F.toInt())
                    cornerRadii = floatArrayOf(dp(18).toFloat(), dp(18).toFloat(), dp(18).toFloat(), dp(18).toFloat(), 0f, 0f, 0f, 0f)
                })
                elevation = dp(18).toFloat()
            }
            val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
            header.addView(TextView(this).apply {
                text = "Audio Tracks"; setTextColor(Color.WHITE); textSize = 17f
                setTypeface(null, android.graphics.Typeface.BOLD)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            header.addView(TextView(this).apply {
                text = "×"; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                setPadding(dp(12), 0, dp(4), dp(4))
                setOnClickListener { playerOverlay.removeView(dim) }
            }, LinearLayout.LayoutParams(dp(44), dp(44)))
            panel.addView(header)
            panel.addView(View(this).apply { setBackgroundColor(0xFF41434B.toInt()) }, LinearLayout.LayoutParams(-1, dp(1)))
            val scroll = ScrollView(this)
            val items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, 0) }
            audioTracks.forEach { track ->
                val trackId = track.id
                val selected = mp.audioTrack == trackId
                items.addView(TextView(this).apply {
                    text = (track.name ?: "Audio Track $trackId") + if (selected) "   ✓" else ""
                    setTextColor(if (selected) 0xFF53D6B0.toInt() else Color.WHITE)
                    textSize = 14f
                    setPadding(dp(10), dp(12), dp(6), dp(12))
                    setOnClickListener {
                        mp.setAudioTrack(trackId)
                        playerOverlay.removeView(dim)
                    }
                }, LinearLayout.LayoutParams(-1, -2))
                items.addView(View(this).apply { setBackgroundColor(0xFF343740.toInt()) }, LinearLayout.LayoutParams(-1, dp(1)))
            }
            scroll.addView(items)
            panel.addView(scroll, LinearLayout.LayoutParams(-1, dp(220)))
            dim.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
            playerOverlay.addView(dim, FrameLayout.LayoutParams(-1, -1))
        } catch (error: Exception) {
            Toast.makeText(this, "Audio track selection unavailable: ${error.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun applyFullscreenVideoSizing() {
        val overlay = playerOverlay
        val video = vlcVideo
        val mp = vlcPlayer
        if (!::playerOverlay.isInitialized || video == null || mp == null) return

        // VLC scale 0 means fit the video to the available output while preserving
        // the video's aspect ratio (no stretching of faces or picture geometry).
        val reapply = Runnable {
            if (playerFullscreen && vlcPlayer === mp && vlcVideo === video &&
                video.width > 0 && video.height > 0) {
                runCatching {
                    // Crop-to-fill: preserve the source aspect ratio while filling
                    // the landscape output; VLC crops the excess edges instead of
                    // stretching the picture or leaving letterbox/pillarbox gaps.
                    mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_FIT_SCREEN)
                    video.invalidate()
                }.onFailure {
                    Log.w("PLAY_MAX_VLC", "Could not reapply fullscreen video sizing", it)
                }
            }
        }
        video.post(reapply)
        video.postDelayed(reapply, 250)
        video.postDelayed(reapply, 600)
    }

    private fun togglePlayerFullscreen() {
        if (!::playerOverlay.isInitialized || playerOverlay.visibility != View.VISIBLE) return
        if (!playerFullscreen) {
            savedOrientation = requestedOrientation
            playerFullscreen = true
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            playerOverlay.layoutParams = FrameLayout.LayoutParams(-1, -1)
            // Re-apply VLC's fit-to-output sizing after the device has completed rotation.
            // This keeps the source aspect ratio and avoids a small, stale-sized 1080p surface.
            applyFullscreenVideoSizing()
        } else {
            playerFullscreen = false
            // Restore the normal inline fit when leaving fullscreen.
            runCatching { vlcPlayer?.setVideoScale(MediaPlayer.ScaleType.SURFACE_BEST_FIT) }
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            playerOverlay.translationX = 0f
            playerOverlay.translationY = 0f
            playerOverlay.layoutParams = FrameLayout.LayoutParams(savedPlayerRect[2], savedPlayerRect[3]).apply {
                leftMargin = savedPlayerRect[0]; topMargin = savedPlayerRect[1]
            }
        }
    }

    private fun stopInlineVlc() {
        vlcPlayer?.let { mp -> saveWatchPosition(lastPlaybackUrl, mp.time, mp.length) }
        playerHandler.removeCallbacks(playerProgress)
        playerHandler.removeCallbacks(hidePlayerControlsRunnable)
        playbackRequested = false
        updateKeepScreenOn()
        lastVlcTime = 0L
        lastVlcProgressAt = 0L
        vlcRecoveryAttempts = 0
        lifecycleWasPlaying = false
        lifecyclePlaybackTime = 0L
        vlcViewsDetachedForPause = false
        runCatching { vlcPlayer?.stop(); vlcPlayer?.detachViews(); vlcPlayer?.release() }
        vlcPlayer = null
        runCatching { vlc?.release() }; vlc = null
        if (::playerOverlay.isInitialized) { playerOverlay.removeAllViews(); playerOverlay.visibility = View.GONE }
        playerPlayPause = null
        playerControlsContainer = null
        playerControlsVisible = true
        playerControlsHideScheduled = false
        if (playerFullscreen) {
            playerFullscreen = false; requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }
    }

    private fun timeText(ms: Long): String {
        val sec = (ms.coerceAtLeast(0L) / 1000); return String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
    }

    private fun handleExternalTelegramLink(url: String): Boolean {
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        val host = uri.host?.lowercase() ?: return false
        if (uri.scheme != "https" || host !in setOf("t.me", "www.t.me", "telegram.me", "www.telegram.me")) {
            return false
        }
        // Open the HTTPS channel in a browser Custom Tab first. The user can then
        // choose Telegram's own "Open in Telegram" action from the browser page.
        return try {
            CustomTabsIntent.Builder().build().launchUrl(this, uri)
            true
        } catch (error: Exception) {
            Log.w("PLAY_MAX", "Custom Tab unavailable; trying the browser", error)
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)
                val browsers = listOf("com.android.chrome", "com.sec.android.app.sbrowser", "org.mozilla.firefox", "com.brave.browser")
                val pm = packageManager
                val browserPackage = browsers.firstOrNull { packageName ->
                    browserIntent.setPackage(packageName)
                    browserIntent.resolveActivity(pm) != null
                }
                browserIntent.setPackage(browserPackage)
                startActivity(browserIntent)
                true
            } catch (fallbackError: Exception) {
                Log.e("PLAY_MAX", "No browser could open Telegram channel URL", fallbackError)
                false
            }
        }
    }

    private fun loadBanner() {
        if (isFinishing || isDestroyed) return

        if (bannerAdUnitId.isBlank()) {
            Log.w("PLAY_MAX_ADS", "Banner not loaded: Firestore Ad Unit ID is empty")
            return
        }
        val screenWidthDp = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()
        val adaptiveAdSize = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, screenWidthDp)
        val adView = AdView(this).apply {
            adUnitId = bannerAdUnitId
            setAdSize(adaptiveAdSize)
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.d("PLAY_MAX_ADS", "Banner loaded")
                    adContainer.visibility = View.VISIBLE
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w("PLAY_MAX_ADS", "Banner failed: ${error.message}")
                    // Keep the reserved black slot; never resize or shift the app on ad failure.
                    adContainer.visibility = View.VISIBLE
                }
            }
        }

        bannerView = adView
        adContainer.removeAllViews()
        // Reserve the exact adaptive banner height at the app's bottom edge.
        // The WebView (including posters, movie details and player) remains above it.
        adContainer.layoutParams = (adContainer.layoutParams as LinearLayout.LayoutParams).apply {
            height = adaptiveAdSize.getHeightInPixels(this@MainActivity)
        }
        adContainer.addView(
            adView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, adaptiveAdSize.getHeightInPixels(this))
        )
        adView.loadAd(AdRequest.Builder().build())
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        // PLAY MAX has only two navigation layers: Home and Movie Details.
        // When Movie Details is open, let its WebView history popstate handler
        // close the whole details page and stop the native VLC overlay together.
        if (customView != null) {
            (window.decorView as? FrameLayout)?.removeView(customView)
            customView = null
            webView.visibility = View.VISIBLE
            adContainer.visibility = View.VISIBLE
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
            requestedOrientation = previousRequestedOrientation
            customViewCallback?.onCustomViewHidden()
            customViewCallback = null
        } else if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else if (::playerOverlay.isInitialized && playerOverlay.visibility == View.VISIBLE) {
            stopInlineVlc()
        } else {
            super.onBackPressed()
        }
    }

    override fun onPause() {
        bannerView?.pause()
        activityInForeground = false
        updateKeepScreenOn()
        // Save the user's playback intent, not VLC isPlaying: VLC can report false
        // briefly while buffering even though the user expects playback to continue.
        vlcPlayer?.let { mp ->
            runCatching {
                lifecycleWasPlaying = playbackRequested && !shareInProgress
                lifecyclePlaybackTime = mp.time.coerceAtLeast(0L)
                saveWatchPosition(lastPlaybackUrl, lifecyclePlaybackTime, mp.length)
                if (playbackRequested || mp.isPlaying) mp.pause()
                val video = vlcVideo
                if (video != null) {
                    mp.detachViews()
                    vlcViewsDetachedForPause = true
                }
            }
        }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        activityInForeground = true
        updateKeepScreenOn()
        bannerView?.resume()

        // The download action intentionally stops and releases VLC before opening
        // the external download page. Recreate the native video surface on return.
        // Re-measure the HTML player slot after the WebView has resumed; stale screen
        // coordinates can otherwise place the VLC surface behind the black modal.
        if (resumeAfterExternalDownload && lastPlaybackUrl.isNotBlank()) {
            restoringExternalDownloadPlayback = true
            resumeAfterExternalDownload = false
            // Clear the WebView's one-shot download guard so the Download Movie
            // button remains usable every time the user returns from the browser.
            webView.postDelayed({
                if (!isFinishing && !isDestroyed) {
                    webView.evaluateJavascript("window.resetPlayMaxDownloadButton && window.resetPlayMaxDownloadButton();", null)
                }
            }, 150L)
            val url = lastPlaybackUrl
            val title = lastPlaybackTitle
            val fallbackX = lastPlaybackX
            val fallbackY = lastPlaybackY
            val fallbackWidth = lastPlaybackWidth
            val fallbackHeight = lastPlaybackHeight
            val position = externalDownloadResumePosition

            fun rebuildPlayer(x: Float, y: Float, width: Float, height: Float) {
                if (isFinishing || isDestroyed || url.isBlank()) return
                if (width <= 0f || height <= 0f) {
                    Log.w("PLAY_MAX", "Player slot has no size after download return; using saved bounds")
                    return
                }
                runCatching {
                    suppressWatchPromptOnce = true
                    showInlineVlc(url, title, x, y, width, height)
                    val expectedPlayer = vlcPlayer
                    if (position > 0L && expectedPlayer != null) {
                        fun restorePosition(attempt: Int) {
                            if (vlcPlayer !== expectedPlayer || isFinishing || isDestroyed) {
                                restoringExternalDownloadPlayback = false
                                return
                            }
                            runCatching {
                                // Poll VLC metadata more frequently and restore regardless of the
                                // transient isPlaying flag; the latter can be false while buffering.
                                if (expectedPlayer.length > 0L || attempt >= 40) {
                                    expectedPlayer.time = if (expectedPlayer.length > 0L)
                                        position.coerceAtMost((expectedPlayer.length - 1L).coerceAtLeast(0L))
                                    else position
                                    playbackRequested = true
                                    updateKeepScreenOn()
                                    if (!expectedPlayer.isPlaying) expectedPlayer.play()
                                    restoringExternalDownloadPlayback = false
                                    playerPlayPause?.text = "Ⅱ"
                                    schedulePlayerControlsAutoHide()
                                } else {
                                    playerHandler.postDelayed({ restorePosition(attempt + 1) }, 250L)
                                }
                            }.onFailure { error ->
                                restoringExternalDownloadPlayback = false
                                Log.w("PLAY_MAX", "Could not restore playback position", error)
                            }
                        }
                        // Start the restore check immediately; don't add another fixed 700 ms wait.
                        playerHandler.post { restorePosition(0) }
                    } else {
                        restoringExternalDownloadPlayback = false
                    }
                }.onFailure { error ->
                    Log.e("PLAY_MAX", "VLC recreation after download return failed", error)
                    Toast.makeText(this, "Could not restore video. Please tap Play again.", Toast.LENGTH_LONG).show()
                }
            }

            webView.postDelayed({
                if (isFinishing || isDestroyed) return@postDelayed
                webView.evaluateJavascript(
                    "(function(){var s=document.querySelector('.player-wrapper');if(!s)return null;var r=s.getBoundingClientRect();return JSON.stringify([r.left,r.top,r.width,r.height]);})()"
                ) { result ->
                    val bounds = runCatching {
                        val raw = if (result != null && result.startsWith("\""))
                            org.json.JSONTokener(result).nextValue() as? String else result
                        org.json.JSONArray(raw ?: "[]")
                    }.getOrNull()
                    if (bounds != null && bounds.length() >= 4) {
                        val x = bounds.optDouble(0, fallbackX.toDouble()).toFloat()
                        val y = bounds.optDouble(1, fallbackY.toDouble()).toFloat()
                        val w = bounds.optDouble(2, fallbackWidth.toDouble()).toFloat()
                        val h = bounds.optDouble(3, fallbackHeight.toDouble()).toFloat()
                        if (w > 0f && h > 0f) rebuildPlayer(x, y, w, h)
                        else rebuildPlayer(fallbackX, fallbackY, fallbackWidth, fallbackHeight)
                    } else {
                        rebuildPlayer(fallbackX, fallbackY, fallbackWidth, fallbackHeight)
                    }
                }
            }, 250L)
            return
        }

        if (!resumeAfterExternalDownload) restoringExternalDownloadPlayback = false

        // Capture the resume decision before scheduling UI work. Reattach the
        // surface first, then restore the timestamp and issue play after layout settles.
        // Returning from WhatsApp/another share target must leave playback paused.
        if (shareInProgress) {
            shareInProgress = false
            lifecycleWasPlaying = false
            playbackRequested = false
            updateKeepScreenOn()
        }
        val shouldResumePlayback = lifecycleWasPlaying
        val savedTime = lifecyclePlaybackTime
        lifecycleWasPlaying = false
        playerOverlay.post {
            val mp = vlcPlayer
            val video = vlcVideo
            if (mp != null && video != null && playerOverlay.visibility == View.VISIBLE) {
                runCatching {
                    if (vlcViewsDetachedForPause) {
                        mp.attachViews(video, null, false, false)
                        vlcViewsDetachedForPause = false
                    }
                    if (shouldResumePlayback) {
                        playbackRequested = true
                        updateKeepScreenOn()
                        playerHandler.postDelayed({
                            if (vlcPlayer === mp && playerOverlay.visibility == View.VISIBLE && playbackRequested) {
                                runCatching {
                                    if (savedTime > 0L) mp.time = savedTime
                                    mp.play()
                                }.onFailure {
                                    Log.e("PLAY_MAX", "Delayed VLC resume failed", it)
                                }
                            }
                        }, 300L)
                    }
                }.onFailure {
                    Toast.makeText(this, "Video resume error: ${it.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroy() {
        stopInlineVlc()
        bannerView?.destroy()
        bannerView = null
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
