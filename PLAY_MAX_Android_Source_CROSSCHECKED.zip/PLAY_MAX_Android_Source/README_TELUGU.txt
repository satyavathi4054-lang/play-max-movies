PLAY MAX Android Source ZIP

Package: com.playmax.movies
AdMob App ID: ca-app-pub-1802093280158632~5562890157
Banner Ad Unit ID: ca-app-pub-1802093280158632/6464908289
Interstitial Ads: NOT enabled / not implemented

UI dimensions retained from the reviewed source: top navbar 52px, bottom navigation 54px.
The Android app reserves a 50dp row below the WebView for the small Banner Ad so it does not cover the HTML bottom navigation.
The splash screen and existing home/player HTML have been retained.

Important: ZIP integrity and source-level ID/configuration checks were performed. An Android APK build and on-device layout/ad playback test have NOT yet been performed.
