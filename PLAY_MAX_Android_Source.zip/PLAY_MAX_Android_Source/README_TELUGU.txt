PLAY MAX Android Source ZIP

ఈ ZIP లో Android Studio source project మరియు app/src/main/assets/index.html ఉన్నాయి.

Package: com.playmax.movies
AdMob App ID: ca-app-pub-1802093280158632~5562890157
Banner: Google official TEST banner ID మాత్రమే.

ఈ update లో: 
- Android status/navigation bar insets root వద్ద ఒక్కసారి మాత్రమే apply అవుతాయి.
- WebView కు insets రెండుసార్లు apply కాకుండా consume చేస్తుంది.
- 50dp test banner row WebView కింద వేరుగా ఉంటుంది.
- HTML లో duplicate body padding rule తొలగించబడింది.
- Bottom navigation 64px గా అలాగే ఉంచబడింది.

ఇది Android source ZIP మాత్రమే; APK కాదు. GitHub workflow build.yml ఈ ZIP ను PLAY_MAX_Android_Source.zip అనే ఖచ్చితమైన పేరుతో repository root లో ఆశిస్తుంది.
