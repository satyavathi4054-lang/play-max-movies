package com.playmax.movies

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var adContainer: FrameLayout
    private var bannerView: AdView? = null

    // Google's official test banner ID. Keep test ads during development.
    private val bannerAdUnitId = "ca-app-pub-3940256099942544/9214589741"

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Draw behind system bars, then apply their insets exactly once to the root.
        // This keeps the WebView content out of the status/navigation bar areas.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.BLACK)
        }

        // Apply safe-area insets once at the root. Consume them so the WebView does
        // not apply the same insets again and shift the page a second time.
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val safeBars = insets.getInsets(
                WindowInsetsCompat.Type.statusBars() or
                    WindowInsetsCompat.Type.navigationBars() or
                    WindowInsetsCompat.Type.displayCutout()
            )
            view.setPadding(safeBars.left, safeBars.top, safeBars.right, safeBars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadsImagesAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            setBackgroundColor(android.graphics.Color.BLACK)
        }

        // Reserve one standard 50dp banner row below the WebView. The HTML bottom
        // navigation remains inside the WebView and is not covered by the ad.
        adContainer = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
        }

        root.addView(
            webView,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )
        root.addView(
            adContainer,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(50)
            )
        )

        setContentView(root)
        ViewCompat.requestApplyInsets(root)

        webView.loadUrl("file:///android_asset/index.html")

        MobileAds.initialize(this) {
            runOnUiThread { loadTestBanner() }
        }
    }

    private fun loadTestBanner() {
        if (isFinishing || isDestroyed) return

        val adView = AdView(this).apply {
            adUnitId = bannerAdUnitId
            setAdSize(AdSize.BANNER)
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.d("PLAY_MAX_ADS", "Test banner loaded")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w("PLAY_MAX_ADS", "Banner failed: ${error.message}")
                }
            }
        }

        bannerView = adView
        adContainer.removeAllViews()
        adContainer.addView(
            adView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(50)
            )
        )
        adView.loadAd(AdRequest.Builder().build())
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onPause() {
        bannerView?.pause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        bannerView?.resume()
    }

    override fun onDestroy() {
        bannerView?.destroy()
        bannerView = null
        if (::webView.isInitialized) {
            webView.destroy()
        }
        super.onDestroy()
    }
}
