PLAY MAX Android project

- Splash and Home screen use the red PLAY / white MAX text branding shown in the reference video.
- Compact top bar: 52px; bottom navigation: 54px.
- Original page bottom clearance is preserved so fixed navigation does not cover scrolling content.
- Launcher icon uses the supplied PLAY MAX app icon. In-app splash/header keep the video text logo.
- AdMob App ID is configured in AndroidManifest.xml.
- Only the supplied Banner Ad Unit ID is configured. No Interstitial Ads are implemented.
- Banner container stays hidden unless an ad successfully loads; ad failure does not reserve blank space.
- Build with JDK 17 and Gradle 8.13+ using: gradle assembleDebug
