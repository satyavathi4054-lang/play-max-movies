PLAY MAX USER APP - FIREBASE TRAFFIC TRACKING

This source ZIP adds one Firestore document to the trafficEvents collection
for each fresh app launch. Fields:
- uid / installationId: random persistent ID stored locally for this app install
- eventType: "open"
- createdAt: Firestore server timestamp
- platform: "android"

The ID is generated once and reused for this installation. No email, name,
movie title, playback history, or watch history is collected.

Firebase project ID in this User App source: play-max-admin.
Admin Dashboard reads the same Firestore project and trafficEvents collection.

IMPORTANT:
The Firebase Firestore Security Rules must permit the signed-in/anonymous
User App to CREATE trafficEvents documents and permit the authenticated Admin
App to READ them. If writes are denied, the User App logs
PLAY_MAX_TRAFFIC "Could not record app-open event" and the Admin Dashboard
will continue to show dashes. Do not enable unrestricted public read/write
rules. Configure least-privilege rules in Firebase Console for your app/admin
authentication model.

Build project folder: PLAY_MAX_Android_Source
Gradle task: :app:assembleDebug
APK output: PLAY_MAX_Android_Source/app/build/outputs/apk/debug/app-debug.apk
