package com.playmax.movies

import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.net.HttpURLConnection
import java.net.URL

@UnstableApi
class NativePlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var activityStopped = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )

        val inputUrl = intent.getStringExtra(EXTRA_URL).orEmpty().trim()
        if (inputUrl.isBlank()) {
            Toast.makeText(this, "Video URL is empty", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("PLAY-MAX Android Media3")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(20_000)
            .setReadTimeoutMs(30_000)

        val selector = DefaultTrackSelector(this)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 1_500, 3_000)
            .build()

        val exo = ExoPlayer.Builder(this)
            .setTrackSelector(selector)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
            .build()
        player = exo

        playerView = PlayerView(this).apply {
            useController = true
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            keepScreenOn = true
            player = exo
            layoutParams = android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        setContentView(playerView)

        exo.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                Log.e(TAG, "Playback failed: ${error.errorCodeName}", error)
                val detail = error.cause?.message?.take(90).orEmpty()
                val message = if (detail.isBlank()) {
                    "Video could not play (${error.errorCodeName})"
                } else {
                    "Video could not play (${error.errorCodeName}): $detail"
                }
                Toast.makeText(this@NativePlayerActivity, message, Toast.LENGTH_LONG).show()
            }
        })

        // Direct stream URLs go straight to Media3. Do not issue an extra GET first:
        // that duplicated request can delay playback and can break signed/Range URLs.
        // Only known /watch/ pages are inspected for a static HTML video/source URL.
        if (isKnownWatchPage(inputUrl)) {
            Thread {
                val resolved = resolveStaticWatchPage(inputUrl)
                mainHandler.post {
                    if (isFinishing || isDestroyed || activityStopped) return@post
                    if (resolved.url == null) {
                        Toast.makeText(
                            this,
                            resolved.error ?: "This is a watch page, not a direct video URL",
                            Toast.LENGTH_LONG
                        ).show()
                        finish()
                    } else {
                        startPlayback(resolved.url)
                    }
                }
            }.start()
        } else {
            startPlayback(inputUrl)
        }
    }

    private data class UrlResolution(val url: String?, val error: String? = null)

    private fun isKnownWatchPage(value: String): Boolean {
        return runCatching {
            val path = Uri.parse(value).path.orEmpty().lowercase()
            path.contains("/watch/")
        }.getOrDefault(false)
    }

    /**
     * Limited support for simple watch pages that contain a literal <video src> or
     * <source src>. JavaScript-generated/encrypted player pages must provide a direct
     * media URL from the server instead; ExoPlayer cannot play HTML pages.
     */
    private fun resolveStaticWatchPage(value: String): UrlResolution {
        var connection: HttpURLConnection? = null
        return try {
            val conn = (URL(value).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true
                connectTimeout = 15_000
                readTimeout = 15_000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/131.0.0.0 Mobile Safari/537.36")
            }
            connection = conn
            val status = conn.responseCode
            if (status !in 200..299) return UrlResolution(null, "Watch page returned HTTP $status")
            val finalUrl = conn.url.toString()
            val type = conn.contentType.orEmpty().lowercase()
            if (!type.contains("text/html") && !type.contains("xhtml")) {
                return UrlResolution(finalUrl)
            }
            val html = conn.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                val out = StringBuilder()
                val buffer = CharArray(8192)
                var total = 0
                while (total < 1024 * 1024) {
                    val count = reader.read(buffer, 0, minOf(buffer.size, 1024 * 1024 - total))
                    if (count <= 0) break
                    out.append(buffer, 0, count)
                    total += count
                }
                out.toString()
            }
            val patterns = listOf(
                Regex("""<(?:video|source)\b[^>]*?\bsrc\s*=\s*['\"]([^'\"]+)['\"]""", RegexOption.IGNORE_CASE),
                Regex("""<(?:video|source)\b[^>]*?\bdata-src\s*=\s*['\"]([^'\"]+)['\"]""", RegexOption.IGNORE_CASE)
            )
            val raw = patterns.firstNotNullOfOrNull { it.find(html)?.groupValues?.getOrNull(1) }
                ?: return UrlResolution(null, "Watch page has no static video URL. Use the server's direct stream URL.")
            val decoded = raw.replace("&amp;", "&").replace("&#38;", "&")
            UrlResolution(URL(URL(finalUrl), decoded).toString())
        } catch (e: Exception) {
            UrlResolution(null, "Cannot inspect watch page: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            connection?.disconnect()
        }
    }

    private fun startPlayback(url: String) {
        val exo = player ?: return
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "PLAY MAX" }
        val item = MediaItem.Builder()
            .setUri(Uri.parse(url))
            .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
        mimeTypeFor(url)?.let(item::setMimeType)
        exo.setMediaItem(item.build())
        exo.prepare()
        exo.playWhenReady = true
        Log.d(TAG, "Media item prepared; URL host=${Uri.parse(url).host}, path=${Uri.parse(url).path}")
    }

    private fun mimeTypeFor(url: String): String? {
        val path = Uri.parse(url).path.orEmpty().lowercase()
        return when {
            path.endsWith(".m3u8") -> MimeTypes.APPLICATION_M3U8
            path.endsWith(".mpd") -> MimeTypes.APPLICATION_MPD
            path.endsWith(".mkv") -> MimeTypes.VIDEO_MATROSKA
            path.endsWith(".mp4") || path.endsWith(".m4v") -> MimeTypes.VIDEO_MP4
            path.endsWith(".webm") -> MimeTypes.VIDEO_WEBM
            else -> null // Let Media3 inspect response headers and sniff the container.
        }
    }

    override fun onStop() {
        activityStopped = true
        playerView?.player = null
        player?.release()
        player = null
        super.onStop()
    }

    override fun onDestroy() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        playerView = null
        super.onDestroy()
    }

    companion object {
        private const val TAG = "PLAY_MAX_PLAYER"
        const val EXTRA_URL = "play_max_stream_url"
        const val EXTRA_TITLE = "play_max_stream_title"
    }
}
