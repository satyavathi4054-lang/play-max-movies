PLAY MAX - UNIVERSAL NATIVE PLAYER UPDATE

ఈ ZIPలో Android Native Media3 ExoPlayer ఇంటిగ్రేషన్ చేర్చబడింది.

ఫార్మాట్లు:
- MP4
- MKV / Matroska (లోపలి video/audio codec పరికరానికి మద్దతు ఉంటే)
- HLS (.m3u8)
- DASH (.mpd)

Androidలో Play Max WebView నుంచి వీడియో URL NativePlayerActivityకి పంపబడుతుంది.
PlayerView యొక్క built-in controls ద్వారా playback, seek, audio/subtitle track menu (స్ట్రీమ్‌లో tracks ఉన్నప్పుడు) అందుబాటులో ఉంటాయి.
Browserలో Android bridge లేనప్పుడు పాత Plyr fallback కొనసాగుతుంది.

ఈ సవరణలో చేసినవి:
- Google Sheets stream_url Android bridge ద్వారా NativePlayerActivityకి పంపే పాత flow అలాగే ఉంచబడింది.
- .m3u8, .mpd, .mkv, .mp4/.m4v వంటి తెలిసిన extensionsకే MIME type నిర్ణయించబడుతుంది.
- Extension లేని server URLను తప్పుగా MP4గా ప్రకటించకుండా మార్చబడింది. Android Media3 response Content-Type/container sniffingను ఉపయోగించగలదు.
- Playerలో error వస్తే error codeతో Toast చూపిస్తుంది; movie title MediaItem metadataలో ఉంచబడుతుంది.

గమనికలు:
- Buffering పూర్తిగా పోతుందని హామీ లేదు. Server throughput, HTTP Range/stream behavior, bitrate, codec మరియు device decoderపై ఆధారపడి ఉంటుంది.
- MKV ఒక container మాత్రమే; ప్రతి MKV codec combination ప్రతి Android పరికరంలో ప్లే అవుతుందని హామీ లేదు.
- ఈ source ZIPను GitHub Actions ద్వారా assembleDebug చేయాలి. APK build మరియు device playback ఇంకా ధృవీకరించబడలేదు.
