# PLAY MAX ADMIN Android App — audited source package

- Android package: `com.playmax.admin`
- Firebase project: `play-max-admin`
- Admin interface: original Firebase-enabled HTML bundled in Android WebView.
- WebView loads local assets through AndroidX WebViewAssetLoader at the HTTPS app-assets origin, rather than `file://`.
- File access from local file URLs is disabled. Only the app-assets origin and required Firebase/Google CDN hosts remain in WebView; other links open externally.
- `firebase-config/google-services.json` is retained as a reference file. This build uses Firebase Web SDK from the HTML, so the Google Services Gradle plugin/native SDK is not required.

## Build
From this directory: `gradle --no-daemon :app:assembleDebug`

## Known limitations — not represented as completed
- Firebase Auth and Firestore must be tested on a real device with the project's actual Firestore rules.
- Movie and Web Series posters are uploaded to ImageKit using short-lived signatures from the Cloudflare Worker, and the returned ImageKit URL is saved in the Firestore content record. The ImageKit Public Key must be entered once in Admin → Settings. The ImageKit Private Key must remain only in Cloudflare Worker Secrets.
- Notifications are local drafts only; FCM delivery is not implemented.
- AdMob settings are local UI values only; AdMob SDK integration is not implemented.
- Users management is a placeholder.

A successful source audit/build does not guarantee Google Play Protect will accept an APK. Play Protect reputation/signing/scanning decisions are separate and cannot be bypassed by changing the ZIP.

## ImageKit integration (v7 package audit)

- Cloudflare auth endpoint configured in the app: `https://play-max-imagekit-auth.satyavathi4054.workers.dev/auth`.
- The app sends the signed-in Firebase user's ID token as a Bearer token to the Worker.
- The Worker verifies the Firebase token and checks that the user's UID matches `OWNER_UID` before returning a short-lived ImageKit upload signature.
- Movie posters upload to `/play-max/movies`; Web Series posters upload to `/play-max/series`; banners upload to `/play-max/banners`.
- The ImageKit Public Key is stored locally in the Admin app Settings. Do not put the ImageKit Private Key in the Android app or repository.
- Banner records are stored in Firestore `banners`. Deleting a banner record does not delete the underlying ImageKit file.
- Runtime upload success still requires a valid ImageKit Public Key, correctly named Cloudflare secrets (`FIREBASE_API_KEY`, `IMAGEKIT_PRIVATE_KEY`, `OWNER_UID`), and the owner Firebase account to match `OWNER_UID`. These runtime checks must be completed on a real device.

## Web Series multi-episode update (v5)
- A Web Series is stored as one document in `content/{seriesId}`.
- Its episodes are stored as individual documents in `content/{seriesId}/episodes/{episodeId}`.
- The Admin form supports adding/removing multiple episode rows before saving.
- Each episode stores `number`, `title`, `url`, `season`, and `updatedAt`.
- The Admin loader reads the `episodes` subcollection and retains compatibility with earlier series records that stored a single `url` / `episodeTitle` / `episodeNumber` on the parent document.
- Firestore subcollections avoid putting all episode URLs into one Firestore document (which has a 1 MiB document-size limit). Actual throughput and quotas remain subject to Firebase project limits.
- Viewer integration is intentionally not changed in this build; it remains a separate final step after Admin testing.
