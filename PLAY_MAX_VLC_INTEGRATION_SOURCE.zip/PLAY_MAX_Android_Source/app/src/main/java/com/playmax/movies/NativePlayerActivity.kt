package com.playmax.movies

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.Locale

/**
 * PLAY MAX native VLC playback screen.
 * Inline WebView layout is intentionally not altered in this first integration pass.
 */
class NativePlayerActivity : AppCompatActivity() {
    private var libVLC: LibVLC? = null
    private var mediaPlayer: MediaPlayer? = null
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var seekBar: SeekBar
    private lateinit var timeLabel: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var userSeeking = false

    private val progress = object : Runnable {
        override fun run() {
            val mp = mediaPlayer
            if (mp != null && !userSeeking) {
                val length = mp.length.coerceAtLeast(0L)
                val time = mp.time.coerceAtLeast(0L)
                seekBar.max = length.coerceAtMost(Int.MAX_VALUE.toLong()).toInt().coerceAtLeast(1)
                seekBar.progress = time.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                timeLabel.text = "${formatTime(time)} / ${formatTime(length)}"
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )

        val url = intent.getStringExtra(EXTRA_URL).orEmpty().trim()
        if (url.isBlank()) {
            Toast.makeText(this, "Video URL is empty", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        buildPlayerUi()
        try {
            val options = arrayListOf("--network-caching=1500", "--avcodec-hw=any")
            val vlc = LibVLC(this, options)
            libVLC = vlc
            mediaPlayer = MediaPlayer(vlc).also { mp ->
                mp.attachViews(videoLayout, null, false, false)
                val media = Media(vlc, Uri.parse(url))
                mp.media = media
                media.release()
                mp.play()
            }
            handler.post(progress)
        } catch (error: Exception) {
            Toast.makeText(this, "VLC could not start: ${error.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun buildPlayerUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        videoLayout = VLCVideoLayout(this)
        root.addView(videoLayout, FrameLayout.LayoutParams(-1, -1))

        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(14))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP,
                intArrayOf(0xDD000000.toInt(), 0x00000000)
            )
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.app_logo)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_START
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(132), dp(42)))
        val title = TextView(this).apply {
            text = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "PLAY MAX" }
            setTextColor(Color.WHITE)
            textSize = 16f
            maxLines = 1
            setPadding(dp(14), 0, 0, 0)
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        overlay.addView(header)

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        seekBar = SeekBar(this)
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(bar: SeekBar?) {
                bar?.let { mediaPlayer?.time = it.progress.toLong() }
                userSeeking = false
            }
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {}
        })
        bottom.addView(seekBar, LinearLayout.LayoutParams(-1, dp(34)))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun button(symbol: String, action: () -> Unit): TextView =
            TextView(this).apply {
                text = symbol
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setPadding(dp(12), dp(4), dp(12), dp(4))
                setOnClickListener { action() }
            }
        controls.addView(button("−10") { mediaPlayer?.let { it.time = (it.time - 10_000).coerceAtLeast(0) } })
        controls.addView(button("▶ / ❚❚") {
            mediaPlayer?.let { if (it.isPlaying) it.pause() else it.play() }
        })
        controls.addView(button("+10") { mediaPlayer?.let { it.time = (it.time + 10_000).coerceAtMost(it.length) } })
        timeLabel = TextView(this).apply {
            text = "00:00 / 00:00"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(10), 0, 0, 0)
        }
        controls.addView(timeLabel)
        bottom.addView(controls)
        overlay.addView(bottom)

        root.addView(overlay, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        val close = TextView(this).apply {
            text = "✕"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { finish() }
        }
        root.addView(close, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        setContentView(root)
    }

    private fun formatTime(ms: Long): String {
        val seconds = (ms / 1000).coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onStop() {
        handler.removeCallbacksAndMessages(null)
        mediaPlayer?.stop()
        mediaPlayer?.detachViews()
        mediaPlayer?.release()
        mediaPlayer = null
        libVLC?.release()
        libVLC = null
        super.onStop()
    }

    companion object {
        const val EXTRA_URL = "play_max_stream_url"
        const val EXTRA_TITLE = "play_max_stream_title"
    }
}
