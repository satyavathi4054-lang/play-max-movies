package com.playmax.movies

import android.annotation.SuppressLint
import android.graphics.Color
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var adContainer: FrameLayout
    private var bannerView: AdView? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var previousRequestedOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private var appRoot: LinearLayout? = null

    // PLAY MAX Banner Ad Unit ID supplied by the user. No interstitial ads are used.
    private val bannerAdUnitId = "ca-app-pub-1802093280158632/2546818349"

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private inner class PlayMaxShareBridge {
        @JavascriptInterface
        fun share(text: String, title: String) {
            runOnUiThread {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, title)
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(sendIntent, "Share with"))
            }
        }
    }

    private inner class PlayMaxPlayerBridge {
        @JavascriptInterface
        fun play(url: String, title: String) {
            if (url.isBlank()) return
            runOnUiThread {
                val intent = Intent(this@MainActivity, NativePlayerActivity::class.java).apply {
                    putExtra(NativePlayerActivity.EXTRA_URL, url)
                    putExtra(NativePlayerActivity.EXTRA_TITLE, title)
                }
                startActivity(intent)
            }
        }
    }


    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }
        appRoot = root

        // Apply system insets once only, preventing duplicate top/bottom offsets in WebView.
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val safeBars = insets.getInsets(
                WindowInsetsCompat.Type.statusBars() or
                    WindowInsetsCompat.Type.navigationBars() or
                    WindowInsetsCompat.Type.displayCutout()
            )
            view.setPadding(safeBars.left, safeBars.top, safeBars.right, safeBars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadsImagesAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    if (customView != null) {
                        callback.onCustomViewHidden()
                        return
                    }

                    customView = view
                    customViewCallback = callback
                    previousRequestedOrientation = requestedOrientation
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

                    (window.decorView as? FrameLayout)?.addView(
                        view,
                        FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            Gravity.CENTER
                        )
                    )
                    webView.visibility = View.GONE
                    adContainer.visibility = View.GONE
                    window.addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
                }

                override fun onHideCustomView() {
                    val view = customView ?: return
                    (window.decorView as? FrameLayout)?.removeView(view)
                    customView = null
                    webView.visibility = View.VISIBLE
                    adContainer.visibility = View.VISIBLE
                    window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
                    requestedOrientation = previousRequestedOrientation
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                }
            }
            addJavascriptInterface(PlayMaxShareBridge(), "PlayMaxBridge")
            addJavascriptInterface(PlayMaxPlayerBridge(), "PlayMaxPlayer")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest
                ): Boolean = handleExternalTelegramLink(request.url.toString())

                @Suppress("DEPRECATION")
                override fun shouldOverrideUrlLoading(view: WebView?, url: String): Boolean =
                    handleExternalTelegramLink(url)
            }
            setBackgroundColor(Color.BLACK)
        }

        // Keep a small black banner slot at the very bottom so the page never jumps
        // when an ad arrives. The slot stays black when AdMob has no fill.
        adContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.VISIBLE
        }

        root.addView(
            webView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        root.addView(
            adContainer,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))
        )

        setContentView(root)
        ViewCompat.requestApplyInsets(root)
        webView.loadUrl("file:///android_asset/index.html")

        MobileAds.initialize(this) {
            runOnUiThread { loadBanner() }
        }
    }

    private fun handleExternalTelegramLink(url: String): Boolean {
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        val host = uri.host?.lowercase() ?: return false
        if (host != "t.me" && host != "www.t.me" && host != "telegram.me" && host != "www.telegram.me") {
            return false
        }

        val telegramIntent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("org.telegram.messenger")
        }
        try {
            startActivity(telegramIntent)
        } catch (_: ActivityNotFoundException) {
            // If the official Telegram package is unavailable, let Android resolve
            // the same HTTPS channel URL to Telegram X, another Telegram client, or a browser.
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
            } catch (error: ActivityNotFoundException) {
                Log.w("PLAY_MAX", "No app can open Telegram link: $url", error)
            }
        }
        return true
    }

    private fun loadBanner() {
        if (isFinishing || isDestroyed) return

        val screenWidthDp = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()
        val adaptiveAdSize = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, screenWidthDp)
        val adView = AdView(this).apply {
            adUnitId = bannerAdUnitId
            setAdSize(adaptiveAdSize)
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.d("PLAY_MAX_ADS", "Banner loaded")
                    adContainer.visibility = View.VISIBLE
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w("PLAY_MAX_ADS", "Banner failed: ${error.message}")
                    // Keep the reserved black slot; never resize or shift the app on ad failure.
                    adContainer.visibility = View.VISIBLE
                }
            }
        }

        bannerView = adView
        adContainer.removeAllViews()
        // Reserve the exact adaptive banner height at the app's bottom edge.
        // The WebView (including posters, movie details and player) remains above it.
        adContainer.layoutParams = (adContainer.layoutParams as LinearLayout.LayoutParams).apply {
            height = adaptiveAdSize.getHeightInPixels(this@MainActivity)
        }
        adContainer.addView(
            adView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, adaptiveAdSize.getHeightInPixels(this))
        )
        adView.loadAd(AdRequest.Builder().build())
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (customView != null) {
            (window.decorView as? FrameLayout)?.removeView(customView)
            customView = null
            webView.visibility = View.VISIBLE
            adContainer.visibility = View.VISIBLE
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
            requestedOrientation = previousRequestedOrientation
            customViewCallback?.onCustomViewHidden()
            customViewCallback = null
        } else if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onPause() {
        bannerView?.pause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        bannerView?.resume()
    }

    override fun onDestroy() {
        bannerView?.destroy()
        bannerView = null
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
